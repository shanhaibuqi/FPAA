function chaos_similation()

initial_values = [0.1, 0, 0];

tspan = [0 500];

[t,sol] = ode45(@ode_system,tspan,initial_values);

x = sol(:,1);
y = sol(:,2);
z = sol(:,3);

%向轨图
figure;
subplot(2,2,1);
plot(x,z); 
xlabel('x');
ylabel('z');
title('The trajectory diagram of XZ');

subplot(2,2,2);
plot(x,y);
xlabel('x');
ylabel('y');
title('The trajectory diagram of XY');

subplot(2,2,3);
plot(y,z);
xlabel('y');
ylabel('z');
title('The trajectory diagram of YZ');

%时序图
figure;
subplot(3,1,1);
plot(t,x);
xlabel('t');
ylabel('x');
title('Time sequence diagram of X');

subplot(3,1,2);
plot(t,y);
xlabel('t');
ylabel('y');
title('Time sequence diagram of Y');

subplot(3,1,3);
plot(t,z);
xlabel('t');
ylabel('z');
title('Time sequence diagram of Z');

end

function dydt = ode_system(~,y)
a=8/7;
b=5/7;
c=9;
d=100/7;

x=y(1);
yy=y(2);
z=y(3);

dxdt = c*(yy - x + b*x +0.5*(a - b)*(abs(x+1)-abs(x-1)));
dydt = x - yy + z;
dzdt = -d*yy;

dydt = [dxdt;dydt;dzdt];

end