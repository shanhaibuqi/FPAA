function chaos_similation()


initial_values = [0.1; 0; 0];

% tspan = [0  100];

dt=5*10^(-3); 

tspan = (0 :dt: 100);


[t,sol] = ode45(@ode_system,tspan,initial_values);

x = sol(:,1);
y = sol(:,2);
z = sol(:,3);

%向轨图
figure;
subplot(2,2,1);
plot(x,z);  
subplot(2,2,2);
plot(x,y);
subplot(2,2,3);
plot(y,z);

%时序图
figure;
subplot(3,1,1);
plot(t,x);  
subplot(3,1,2);
plot(t,y);
subplot(3,1,3);
plot(t,z);
end

function dydt = ode_system(~,y)
a=10;
b=28;
c=8/3;

x=y(1);
yy=y(2);
z=y(3);

dxdt = a*(yy-x);
dydt = -x*z+b*x-yy;
dzdt = x*yy-c*z;

dydt = [dxdt;dydt;dzdt];

end