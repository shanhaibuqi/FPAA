function chaos_similation()


initial_values = [0.1, 0, 0];

tspan = [0 1000];

[t,sol] = ode45(@ode_system,tspan,initial_values);

x = sol(:,1);
y = sol(:,2);
z = sol(:,3);

%向轨图
figure;
subplot(2,2,1);
plot(x,z);  
subplot(2,2,2);
plot(x,y);
subplot(2,2,3);
plot(y,z);

%时序图
figure;
subplot(3,1,1);
plot(t,x);  
subplot(3,1,2);
plot(t,y);
subplot(3,1,3);
plot(t,z);

% %3维图像
% figure;
% plot3(sol(:, 1), sol(:, 2), sol(:, 3), 'LineWidth', 2);
end

function dydt = ode_system(~,y)
a=0.2;
b=0.2;
c=5.7;
k=10;%缩小系数的倒数

x=y(1);
yy=y(2);
z=y(3);

dxdt = - (yy + z);
dydt = x + a*yy;
dzdt = b/k + k*z*x - z*c;

dydt = [dxdt;dydt;dzdt];

end