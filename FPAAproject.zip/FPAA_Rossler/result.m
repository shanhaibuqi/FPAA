% 指定CSV文件路径
csvFilePath = 'chao1.csv';

% 读取CSV文件
 % 假设数据从第二行开始，因为第一行可能是标题

% 提取时间和状态变量
time = data(:, 1);
x = data(:, 2);
y = data(:, 3);
z = data(:, 4);

% 创建一张图
figure;

% 绘制 x 对时间的关系
subplot(3, 1, 1);
plot(time, x, 'LineWidth', 1.5);
title('x 对时间的关系');
xlabel('时间');
ylabel('x');

% 绘制 y 对时间的关系
subplot(3, 1, 2);
plot(time, y, 'LineWidth', 1.5);
title('y 对时间的关系');
xlabel('时间');
ylabel('y');

% 绘制 z 对时间的关系
subplot(3, 1, 3);
plot(time, z, 'LineWidth', 1.5);
title('z 对时间的关系');
xlabel('时间');
ylabel('z');


% 调整图的布局
sgtitle('状态变量对时间的关系');
