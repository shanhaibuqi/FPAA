% x1 = linspace(-3,3,256);
% 
% y1 = zeros(1,256);
% 
% for i=1:256
%     y1(i) = 1/(1+25*x(i)^2);
% end
% 
% data = [y1'  x1'];
% writematrix(data , "tranferfunction.csv");

x1 = linspace(-3,3,256);

y1 = zeros(1,256);

for i=1:256
    y1(i) = 1/((4*x(i)^2)+1);
end

data = [y1'  x1'];
writematrix(data , "tranferfunction1.csv");