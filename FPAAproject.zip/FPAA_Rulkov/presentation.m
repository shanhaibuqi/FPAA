csvFilePath = "test1";

data = readmatrix(csvFilePath);

time = data(:, 1);
x = data(:, 2);
y = data(:, 3);


figure;
subplot(2,1,1);
plot(time,x);
subplot(2,1,2);
plot(time,y);

% data = readmatrix(csvFilePath);
% 
% x = data(:, 1);
% plot(x);

% data = readmatrix(csvFilePath);
% 
% y = data(:, 1);
% x = data(:, 2);
% 
% figure;
% plot(x,y);