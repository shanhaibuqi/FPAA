% 系统参数
a = 4;
b = 0.01;
c = -1;
d = 1;
x0 = 1;
y0 = 0;
num_steps = 1000;

% 初始化数组以存储结果
x_values = zeros(1, num_steps);
y_values = zeros(1, num_steps);

% 初始条件
x_values(1) = x0;
y_values(1) = y0;

% Runge-Kutta算法模拟
for n = 1:num_steps-1
    % 计算k1
    k1_x = a / (1 + x_values(n)^2) + d * y_values(n);
    k1_y = y_values(n) - (b * (x_values(n) - c));
    
    % 计算k2
    k2_x = a / (1 + (x_values(n) + 0.5 * k1_x)^2) + d * (y_values(n) + 0.5 * k1_y);
    k2_y = (y_values(n) + 0.5 * k1_y) - (b * (x_values(n) + 0.5 * k1_x - c));
    
    % 计算k3
    k3_x = a / (1 + (x_values(n) + 0.5 * k2_x)^2) + d * (y_values(n) + 0.5 * k2_y);
    k3_y = (y_values(n) + 0.5 * k2_y) - (b * (x_values(n) + 0.5 * k2_x - c));
    
    % 计算k4
    k4_x = a / (1 + (x_values(n) + k3_x)^2) + d * (y_values(n) + k3_y);
    k4_y = (y_values(n) + k3_y) - (b * (x_values(n) + k3_x - c));
    
    % 更新状态变量
    x_values(n+1) = x_values(n) + (1/6) * (k1_x + 2*k2_x + 2*k3_x + k4_x);
    y_values(n+1) = y_values(n) + (1/6) * (k1_y + 2*k2_y + 2*k3_y + k4_y);
end

% 绘制结果
figure;
plot(1:num_steps, x_values, 'b', 1:num_steps, y_values, 'r');
legend('x', 'y');
xlabel('时间步数');
ylabel('状态变量值');
title('离散系统模拟');
