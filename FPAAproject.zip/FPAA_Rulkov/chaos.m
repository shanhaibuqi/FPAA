% 参数
a = 4;
b = 0.01;
c = -1;
d = 1;

% 初始值
x0 = 0;
y0 = 0;

% 迭代次数
iterations = 1000;

% 初始化数组
x = zeros(1, iterations);
y = zeros(1, iterations);

% 设置初始值
x(1) = x0;
y(1) = y0;

%缩放因子
scale_factor = 2;

% 迭代
for n = 1:iterations-1
    x(n+1) = (a/scale_factor) / (1 + (scale_factor^2)*x(n)^2) + d * y(n);
    y(n+1) = (y(n) - (b/scale_factor) * (scale_factor*x(n) - c));
end

%原函数
%x(n+1) = a/ (1 + x(n)^2) + d * y(n);
%y(n+1) = y(n) - (b * (x(n) - c));

% 绘图
figure;
plot(x, y);
title('混沌系统轨迹');
xlabel('x');
ylabel('y');

% 绘制轨迹图
figure;
subplot(2,1,1);
plot(x, 'b');
title('x 的时序图');
xlabel('迭代次数');
ylabel('x');

subplot(2,1,2);
plot(y, 'r');
title('y 的时序图');
xlabel('迭代次数');
ylabel('y');

