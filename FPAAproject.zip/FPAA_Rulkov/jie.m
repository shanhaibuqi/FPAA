% 系统参数
a = 4;
b = 0.01;
c = -1;
d = 1;

% 初始条件
x0 = 0;
y0 = 0;

% 模拟时间步数
num_steps = 1000;

% 使用Runge-Kutta求解器
[x, y] = runge_kutta_solver(a, b, c, d, x0, y0, num_steps);

% 绘制结果
figure;
subplot(2,1,1);
plot(0:num_steps, x, '-.');
title('x(n) vs n');
xlabel('n');
ylabel('x(n)');

subplot(2,1,2);
plot(0:num_steps, y, '-.');
title('y(n) vs n');
xlabel('n');
ylabel('y(n)');
