function chaos_similation()


initial_values = [0, 0];

tspan = [0 1000];

[t,sol] = ode45(@ode_system,tspan,initial_values);

x = sol(:,1);
y = sol(:,2);

%向轨图
figure;
plot(x,y); 
xlabel('x');
ylabel('y');
title('The trajectory diagram of XY');

%时序图
figure;
subplot(2,1,1);
plot(t,x);
xlabel('t');
ylabel('x');
title('Time sequence diagram of X');

subplot(2,1,2);
plot(t,y);
xlabel('t');
ylabel('y');
title('Time sequence diagram of Y');


end

function dydt = ode_system(~,y)
a=1;
b=0.01;
c=-1;
d=1;

x=y(1);
yy=y(2);

dxdt = a/ (1 + x^2) + d * yy;
dydt = yy - b * (x - c);

dydt = [dxdt;dydt];

end