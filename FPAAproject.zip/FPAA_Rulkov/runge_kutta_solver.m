function [x, y] = runge_kutta_solver(a, b, c, d, x0, y0, num_steps)
    % 初始条件
    x = zeros(1, num_steps+1);
    y = zeros(1, num_steps+1);
    x(1) = x0;
    y(1) = y0;

    % 四阶Runge-Kutta算法
    for n = 1:num_steps
        k1x = a / (1 + x(n)^2) + d * y(n);
        k1y = y(n) - b * (x(n) - c);

        k2x = a / (1 + (x(n) + 0.5*k1x)^2) + d * (y(n) + 0.5*k1y);
        k2y = (y(n) + 0.5*k1y) - b * (x(n) + 0.5*k1x - c);

        k3x = a / (1 + (x(n) + 0.5*k2x)^2) + d * (y(n) + 0.5*k2y);
        k3y = (y(n) + 0.5*k2y) - b * (x(n) + 0.5*k2x - c);

        k4x = a / (1 + (x(n) + k3x)^2) + d * (y(n) + k3y);
        k4y = (y(n) + k3y) - b * (x(n) + k3x - c);

        x(n+1) = x(n) + (1/6) * (k1x + 2*k2x + 2*k3x + k4x);
        y(n+1) = y(n) + (1/6) * (k1y + 2*k2y + 2*k3y + k4y);
    end
end

