#pragma once

#include "systemB_IC_Integrator1.h"
#include "systemB_IC_Integrator2.h"
#include "systemB_IC_Integrator3.h"
#include "systemB_IC_SumDiff1.h"
#include "systemB_IC_SumDiff2.h"
#include "systemB_IC_SumDiff3.h"

class systemB_IC
{
public:
   systemB_IC();

   an_Byte GetDeviceID();

   void ExecutePrimaryConfig(bool Reset);	// Dave Lovell added bool Reset
   void ExecuteReconfig(bool x=false);
   void ExecuteReset();

   void AppendFullReconfig();

// Public CAM member variables for easy access to the chip's CAMs
public:
   systemB_IC_Integrator1 Integrator1;
   systemB_IC_Integrator2 Integrator2;
   systemB_IC_Integrator3 Integrator3;
   systemB_IC_SumDiff1 SumDiff1;
   systemB_IC_SumDiff2 SumDiff2;
   systemB_IC_SumDiff3 SumDiff3;

private:
   an_Chip m_instance;
};
