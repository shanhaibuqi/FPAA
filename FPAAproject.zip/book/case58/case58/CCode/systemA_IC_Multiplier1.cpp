#include "stdafx.h"
#include "systemA_IC_Multiplier1.h"

systemA_IC_Multiplier1::systemA_IC_Multiplier1()
{
   m_instance = an_systemA_IC_Multiplier1;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the multiplication factor of  
//  this module.                                                  
//-----------------------------------------------------------
double systemA_IC_Multiplier1::fixedp_setMultiplier(double M)
{
   return an_fixedp_setMultiplier(m_instance, M);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the multiplication   
//  factor of this module.                                        
//-----------------------------------------------------------
double systemA_IC_Multiplier1::setMultiplier(double M)
{
   return an_setMultiplier(m_instance, M);
}

