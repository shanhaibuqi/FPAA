#pragma once

class systemA_IC_Multiplier1
{
public:
   systemA_IC_Multiplier1();

   //-----------------------------------------------------------
   //  A fixed-point method for setting the multiplication factor of  
   //  this module.                                                  
   //-----------------------------------------------------------
   double fixedp_setMultiplier(double M);

   //-----------------------------------------------------------
   //  A full floating-point method for setting the multiplication   
   //  factor of this module.                                        
   //-----------------------------------------------------------
   double setMultiplier(double M);

private:
   an_CAM m_instance;
};
