#pragma once

#include "systemA_IC_GainHalf1.h"
#include "systemA_IC_Multiplier1.h"
#include "systemA_IC_Multiplier2.h"
#include "systemA_IC_SumDiff1.h"
#include "systemA_IC_SumDiff2.h"

class systemA_IC
{
public:
   systemA_IC();

   an_Byte GetDeviceID();

   void ExecutePrimaryConfig(bool Reset);	// Dave Lovell added bool Reset
   void ExecuteReconfig(bool x=false);
   void ExecuteReset();

   void AppendFullReconfig();

// Public CAM member variables for easy access to the chip's CAMs
public:
   systemA_IC_GainHalf1 GainHalf1;
   systemA_IC_Multiplier1 Multiplier1;
   systemA_IC_Multiplier2 Multiplier2;
   systemA_IC_SumDiff1 SumDiff1;
   systemA_IC_SumDiff2 SumDiff2;

private:
   an_Chip m_instance;
};
