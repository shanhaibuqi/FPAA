#include "stdafx.h"
#include "systemB_IC_Integrator3.h"

systemB_IC_Integrator3::systemB_IC_Integrator3()
{
   m_instance = an_systemB_IC_Integrator3;
}

//-----------------------------------------------------------
//  A full floating-point method for setting the Integration      
//  constant (in 1/microseconds) of this module.                  
//-----------------------------------------------------------
double systemB_IC_Integrator3::setIntegrator(double K)
{
   return an_setIntegrator(m_instance, K);
}

