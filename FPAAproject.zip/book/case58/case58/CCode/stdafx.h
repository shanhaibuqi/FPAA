#pragma once

#define WINVER 0x0501

// Exclude rarely-used stuff from Windows header
#define WIN32_LEAN_AND_MEAN

#include <afxwin.h>

#include "ApiCode.h"
#include "CAMCode.h"
