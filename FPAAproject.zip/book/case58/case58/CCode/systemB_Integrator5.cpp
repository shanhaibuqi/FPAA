#include "stdafx.h"
#include "systemB_Integrator5.h"

systemB_Integrator5::systemB_Integrator5()
{
   m_instance = an_systemB_Integrator5;
}

//-----------------------------------------------------------
//  A full floating-point method for setting the Integration      
//  constant (in 1/microseconds) of this module.                  
//-----------------------------------------------------------
double systemB_Integrator5::setIntegrator(double K)
{
   return an_setIntegrator(m_instance, K);
}

