#include "stdafx.h"
#include "systemA_IC_SumDiff1.h"

systemA_IC_SumDiff1::systemA_IC_SumDiff1()
{
   m_instance = an_systemA_IC_SumDiff1;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemA_IC_SumDiff1::fixedp_setGainSumDiff_2in(double G1, double G2)
{
   an_fixedp_setGainSumDiff_2in(m_instance, G1, G2);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemA_IC_SumDiff1::setGainSumDiff_2in(double G1, double G2)
{
   an_setGainSumDiff_2in(m_instance, G1, G2);
}

