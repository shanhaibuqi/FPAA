#include "stdafx.h"
#include "systemB_Integrator6.h"

systemB_Integrator6::systemB_Integrator6()
{
   m_instance = an_systemB_Integrator6;
}

//-----------------------------------------------------------
//  A full floating-point method for setting the Integration      
//  constant (in 1/microseconds) of this module.                  
//-----------------------------------------------------------
double systemB_Integrator6::setIntegrator(double K)
{
   return an_setIntegrator(m_instance, K);
}

