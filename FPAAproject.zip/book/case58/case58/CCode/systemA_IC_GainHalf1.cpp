#include "stdafx.h"
#include "systemA_IC_GainHalf1.h"

systemA_IC_GainHalf1::systemA_IC_GainHalf1()
{
   m_instance = an_systemA_IC_GainHalf1;
}

//-----------------------------------------------------------
//  A full fixed-point method for setting the gain of the module.  
//  It accepts floating-point inputs and returns a floating-point  
//  result.                                                       
//-----------------------------------------------------------
double systemA_IC_GainHalf1::fixed_setGainHalf(double G)
{
   return an_fixed_setGainHalf(m_instance, G);
}

//-----------------------------------------------------------
//  A full floating point method for setting the gain of this     
//  module.                                                       
//-----------------------------------------------------------
double systemA_IC_GainHalf1::setGainHalf(double G)
{
   return an_setGainHalf(m_instance, G);
}

