#include "stdafx.h"
#include "systemA_IC_SumDiff2.h"

systemA_IC_SumDiff2::systemA_IC_SumDiff2()
{
   m_instance = an_systemA_IC_SumDiff2;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemA_IC_SumDiff2::fixedp_setGainSumDiff_3in(double G1, double G2, double G3)
{
   an_fixedp_setGainSumDiff_3in(m_instance, G1, G2, G3);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemA_IC_SumDiff2::setGainSumDiff_3in(double G1, double G2, double G3)
{
   an_setGainSumDiff_3in(m_instance, G1, G2, G3);
}

