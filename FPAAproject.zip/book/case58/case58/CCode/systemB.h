#pragma once

#include "systemB_Integrator4.h"
#include "systemB_Integrator5.h"
#include "systemB_Integrator6.h"
#include "systemB_SumDiff4.h"
#include "systemB_SumDiff5.h"
#include "systemB_SumDiff6.h"

class systemB
{
public:
   systemB();

   an_Byte GetDeviceID();

   void ExecutePrimaryConfig(bool Reset);	// Dave Lovell added bool Reset
   void ExecuteReconfig(bool x=false);
   void ExecuteReset();

   void AppendFullReconfig();

// Public CAM member variables for easy access to the chip's CAMs
public:
   systemB_Integrator4 Integrator4;
   systemB_Integrator5 Integrator5;
   systemB_Integrator6 Integrator6;
   systemB_SumDiff4 SumDiff4;
   systemB_SumDiff5 SumDiff5;
   systemB_SumDiff6 SumDiff6;

private:
   an_Chip m_instance;
};
