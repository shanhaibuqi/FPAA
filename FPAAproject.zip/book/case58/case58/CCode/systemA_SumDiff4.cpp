#include "stdafx.h"
#include "systemA_SumDiff4.h"

systemA_SumDiff4::systemA_SumDiff4()
{
   m_instance = an_systemA_SumDiff4;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemA_SumDiff4::fixedp_setGainSumDiff_2in(double G1, double G2)
{
   an_fixedp_setGainSumDiff_2in(m_instance, G1, G2);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemA_SumDiff4::setGainSumDiff_2in(double G1, double G2)
{
   an_setGainSumDiff_2in(m_instance, G1, G2);
}

