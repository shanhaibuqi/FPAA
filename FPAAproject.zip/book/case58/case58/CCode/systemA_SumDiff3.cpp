#include "stdafx.h"
#include "systemA_SumDiff3.h"

systemA_SumDiff3::systemA_SumDiff3()
{
   m_instance = an_systemA_SumDiff3;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemA_SumDiff3::fixedp_setGainSumDiff_3in(double G1, double G2, double G3)
{
   an_fixedp_setGainSumDiff_3in(m_instance, G1, G2, G3);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemA_SumDiff3::setGainSumDiff_3in(double G1, double G2, double G3)
{
   an_setGainSumDiff_3in(m_instance, G1, G2, G3);
}

