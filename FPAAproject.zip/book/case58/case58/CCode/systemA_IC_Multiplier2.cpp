#include "stdafx.h"
#include "systemA_IC_Multiplier2.h"

systemA_IC_Multiplier2::systemA_IC_Multiplier2()
{
   m_instance = an_systemA_IC_Multiplier2;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the multiplication factor of  
//  this module.                                                  
//-----------------------------------------------------------
double systemA_IC_Multiplier2::fixedp_setMultiplier(double M)
{
   return an_fixedp_setMultiplier(m_instance, M);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the multiplication   
//  factor of this module.                                        
//-----------------------------------------------------------
double systemA_IC_Multiplier2::setMultiplier(double M)
{
   return an_setMultiplier(m_instance, M);
}

