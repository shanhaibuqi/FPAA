#pragma once

#include "systemA_GainHalf2.h"
#include "systemA_Multiplier3.h"
#include "systemA_Multiplier4.h"
#include "systemA_SumDiff3.h"
#include "systemA_SumDiff4.h"

class systemA
{
public:
   systemA();

   an_Byte GetDeviceID();

   void ExecutePrimaryConfig(bool Reset);	// Dave Lovell added bool Reset
   void ExecuteReconfig(bool x=false);
   void ExecuteReset();

   void AppendFullReconfig();

// Public CAM member variables for easy access to the chip's CAMs
public:
   systemA_GainHalf2 GainHalf2;
   systemA_Multiplier3 Multiplier3;
   systemA_Multiplier4 Multiplier4;
   systemA_SumDiff3 SumDiff3;
   systemA_SumDiff4 SumDiff4;

private:
   an_Chip m_instance;
};
