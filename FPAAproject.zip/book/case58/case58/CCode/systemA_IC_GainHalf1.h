#pragma once

class systemA_IC_GainHalf1
{
public:
   systemA_IC_GainHalf1();

   //-----------------------------------------------------------
   //  A full fixed-point method for setting the gain of the module.  
   //  It accepts floating-point inputs and returns a floating-point  
   //  result.                                                       
   //-----------------------------------------------------------
   double fixed_setGainHalf(double G);

   //-----------------------------------------------------------
   //  A full floating point method for setting the gain of this     
   //  module.                                                       
   //-----------------------------------------------------------
   double setGainHalf(double G);

private:
   an_CAM m_instance;
};
