#include "stdafx.h"
#include "systemB_SumDiff5.h"

systemB_SumDiff5::systemB_SumDiff5()
{
   m_instance = an_systemB_SumDiff5;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemB_SumDiff5::fixedp_setGainSumDiff_2in(double G1, double G2)
{
   an_fixedp_setGainSumDiff_2in(m_instance, G1, G2);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemB_SumDiff5::setGainSumDiff_2in(double G1, double G2)
{
   an_setGainSumDiff_2in(m_instance, G1, G2);
}

