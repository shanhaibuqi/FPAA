#include "stdafx.h"
#include "systemA_Multiplier4.h"

systemA_Multiplier4::systemA_Multiplier4()
{
   m_instance = an_systemA_Multiplier4;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the multiplication factor of  
//  this module.                                                  
//-----------------------------------------------------------
double systemA_Multiplier4::fixedp_setMultiplier(double M)
{
   return an_fixedp_setMultiplier(m_instance, M);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the multiplication   
//  factor of this module.                                        
//-----------------------------------------------------------
double systemA_Multiplier4::setMultiplier(double M)
{
   return an_setMultiplier(m_instance, M);
}

