#ifndef CAMCODE_H
#define CAMCODE_H

#include "ApiCode.h"

/********************************************************************\
*                      AnadigmDesigner2 C Code                       *
*--------------------------------------------------------------------*
*                                                                    *
*  File:      CAMCode.h                                              *
*  Circuit:   case58.ad2                                             *
*  Generated: October 20, 2024:  03:52 PM                            *
*  Version:   2.8.0.10 -  (Standard) - Release                       *
*  Copyright: Copyright � 2002 Anadigm. All rights reserved.         *
*                                                                    *
\********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*##################################################################*\
#                                                                    #
#                            GainHalf.cam                            #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                               Gain                               (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                       fixed_setGainHalf                        |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_fixed_setGainHalf(an_CAM cam, double G);             
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full fixed-point method for setting the gain of the module. |
  |  It accepts floating-point inputs and returns a floating-point |
  |  result.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf2           an_systemA_GainHalf2 an_systemA           |
  |  GainHalf1           an_systemA_IC_GainHalf1 an_systemA_IC      |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                          setGainHalf                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setGainHalf(an_CAM cam, double G);                   
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating point method for setting the gain of this     |
  |  module.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf2           an_systemA_GainHalf2 an_systemA           |
  |  GainHalf1           an_systemA_IC_GainHalf1 an_systemA_IC      |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                           Integrator.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Integrator                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                         setIntegrator                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setIntegrator(an_CAM cam, double K);                 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the Integration      |
  |  constant (in 1/microseconds) of this module.                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Integrator1         an_systemB_IC_Integrator1 an_systemB_IC      |
  |  Integrator2         an_systemB_IC_Integrator2 an_systemB_IC      |
  |  Integrator3         an_systemB_IC_Integrator3 an_systemB_IC      |
  |  Integrator4         an_systemB_Integrator4 an_systemB         |
  |  Integrator5         an_systemB_Integrator5 an_systemB         |
  |  Integrator6         an_systemB_Integrator6 an_systemB         |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                           Multiplier.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Multiplier                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                      fixedp_setMultiplier                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_fixedp_setMultiplier(an_CAM cam, double M);          
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the multiplication factor of |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier1         an_systemA_IC_Multiplier1 an_systemA_IC      |
  |  Multiplier2         an_systemA_IC_Multiplier2 an_systemA_IC      |
  |  Multiplier3         an_systemA_Multiplier3 an_systemA         |
  |  Multiplier4         an_systemA_Multiplier4 an_systemA         |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                         setMultiplier                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setMultiplier(an_CAM cam, double M);                 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the multiplication   |
  |  factor of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier1         an_systemA_IC_Multiplier1 an_systemA_IC      |
  |  Multiplier2         an_systemA_IC_Multiplier2 an_systemA_IC      |
  |  Multiplier3         an_systemA_Multiplier3 an_systemA         |
  |  Multiplier4         an_systemA_Multiplier4 an_systemA         |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                            SumDiff.cam                             #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                             SumDiff                              (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                   fixedp_setGainSumDiff_2in                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_fixedp_setGainSumDiff_2in(an_CAM cam, double G1, double G2); 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the gain of the inputs of    |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff1            an_systemA_IC_SumDiff1 an_systemA_IC      |
  |  SumDiff4            an_systemA_SumDiff4 an_systemA            |
  |  SumDiff1            an_systemB_IC_SumDiff1 an_systemB_IC      |
  |  SumDiff2            an_systemB_IC_SumDiff2 an_systemB_IC      |
  |  SumDiff3            an_systemB_IC_SumDiff3 an_systemB_IC      |
  |  SumDiff4            an_systemB_SumDiff4 an_systemB            |
  |  SumDiff5            an_systemB_SumDiff5 an_systemB            |
  |  SumDiff6            an_systemB_SumDiff6 an_systemB            |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                   fixedp_setGainSumDiff_3in                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_fixedp_setGainSumDiff_3in(an_CAM cam, double G1, double G2, double G3); 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the gain of the inputs of    |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff2            an_systemA_IC_SumDiff2 an_systemA_IC      |
  |  SumDiff3            an_systemA_SumDiff3 an_systemA            |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                       setGainSumDiff_2in                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_setGainSumDiff_2in(an_CAM cam, double G1, double G2);  
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the gain of the      |
  |  inputs of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff1            an_systemA_IC_SumDiff1 an_systemA_IC      |
  |  SumDiff4            an_systemA_SumDiff4 an_systemA            |
  |  SumDiff1            an_systemB_IC_SumDiff1 an_systemB_IC      |
  |  SumDiff2            an_systemB_IC_SumDiff2 an_systemB_IC      |
  |  SumDiff3            an_systemB_IC_SumDiff3 an_systemB_IC      |
  |  SumDiff4            an_systemB_SumDiff4 an_systemB            |
  |  SumDiff5            an_systemB_SumDiff5 an_systemB            |
  |  SumDiff6            an_systemB_SumDiff6 an_systemB            |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                       setGainSumDiff_3in                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_setGainSumDiff_3in(an_CAM cam, double G1, double G2, double G3); 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the gain of the      |
  |  inputs of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff2            an_systemA_IC_SumDiff2 an_systemA_IC      |
  |  SumDiff3            an_systemA_SumDiff3 an_systemA            |
  |                                                                |
  \*--------------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif /* CAMCODE_H */
