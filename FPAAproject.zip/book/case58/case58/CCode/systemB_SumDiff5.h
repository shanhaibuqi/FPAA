#pragma once

class systemB_SumDiff5
{
public:
   systemB_SumDiff5();

   //-----------------------------------------------------------
   //  A fixed-point method for setting the gain of the inputs of    
   //  this module.                                                  
   //-----------------------------------------------------------
   void fixedp_setGainSumDiff_2in(double G1, double G2);

   //-----------------------------------------------------------
   //  A full floating-point method for setting the gain of the      
   //  inputs of this module.                                        
   //-----------------------------------------------------------
   void setGainSumDiff_2in(double G1, double G2);

private:
   an_CAM m_instance;
};
