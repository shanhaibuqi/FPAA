#include "stdafx.h"
#include "systemA_Multiplier3.h"

systemA_Multiplier3::systemA_Multiplier3()
{
   m_instance = an_systemA_Multiplier3;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the multiplication factor of  
//  this module.                                                  
//-----------------------------------------------------------
double systemA_Multiplier3::fixedp_setMultiplier(double M)
{
   return an_fixedp_setMultiplier(m_instance, M);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the multiplication   
//  factor of this module.                                        
//-----------------------------------------------------------
double systemA_Multiplier3::setMultiplier(double M)
{
   return an_setMultiplier(m_instance, M);
}

