#include "stdafx.h"
#include "case58.h"
#include "case58Dlg.h"
#include "DownloadManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// The one and only case58App object
case58App theApp;

BEGIN_MESSAGE_MAP(case58App, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


case58App::case58App()
{

}

BOOL case58App::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();

   // Set the key for MFC uses to read\write the registry.  The final location will be
   //   HKEY_CURRENT_USER\Software\YourCompany\case58\ 
   SetRegistryKey("YourCompany");

   // Read port settings from the registry.
   DownloadManager::Instance()->LoadPortSettings(CString(m_pszRegistryKey) + "\\" + m_pszProfileName);

   // Show the main dialog window
	case58Dlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

   // Save port settings to the registry.
   DownloadManager::Instance()->SavePortSettings(CString(m_pszRegistryKey) + "\\" + m_pszProfileName);

   // The window has closed, so we return FALSE here to go ahead and
   // terminate the application.
   return FALSE;
}
