#pragma once

#include "resource.h"
#include "systemA.h"
#include "systemA_IC.h"
#include "systemB.h"
#include "systemB_IC.h"

class case58Dlg : public CDialog
{
public:
	case58Dlg(CWnd* pParent = NULL);

	enum { IDD = IDD_CASE58_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();

   // This is used to handle the Enter key when the focus is on an edit control.
   virtual BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

   afx_msg void OnPort();
   afx_msg void OnDownload();
   afx_msg void OnReset();
   afx_msg void OnAbout();

   afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
   afx_msg void OnSampleEditChanged();


private:
   void ConfigureAboutMenu();
   void UpdateSampleControls();

	HICON m_hIcon;
   systemA m_systemA;
   systemA_IC m_systemA_IC;
   systemB m_systemB;
   systemB_IC m_systemB_IC;

   CEdit m_sampleEdit;
   CSliderCtrl m_sampleSlider;

   double m_sampleValue;
   double m_sampleMin;
   double m_sampleMax;

	DECLARE_MESSAGE_MAP()
};
