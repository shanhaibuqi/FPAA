#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

class case58App : public CWinApp
{
public:
	case58App();

protected:
	virtual BOOL InitInstance();

private:
	DECLARE_MESSAGE_MAP()
};

extern case58App theApp;