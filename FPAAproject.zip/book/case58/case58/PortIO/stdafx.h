#pragma once

#define WINVER 0x0501

#define VC_EXTRALEAN

#include <afx.h>
#include <afxwin.h>
