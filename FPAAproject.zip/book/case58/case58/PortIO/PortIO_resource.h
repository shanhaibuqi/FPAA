//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PortIO.rc
//
#define IDD_SELECT_PORT                 9000
#define IDC_PC_SERIAL_PORT              9400
#define IDC_PC_PORT_STATUS              9401
#define IDC_PC_SERIALBAUDRATE           9402
#define IDC_PC_BAUD_RATE_TEXT           9404
#define IDC_PC_SETTING_LABEL            9404
#define IDC_DCLK                        9405
#define IDC_DIN                         9406
#define IDC_DIN_TEXT                    9407
#define IDC_DCLK_TEXT                   9408

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        9004
#define _APS_NEXT_COMMAND_VALUE         41000
#define _APS_NEXT_CONTROL_VALUE         9409
#define _APS_NEXT_SYMED_VALUE           9900
#endif
#endif
