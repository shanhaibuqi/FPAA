clc
clear 
close all

data = readmatrix('test.csv');

t = data(:,1);
x = data(:,2);
y = data(:,3);
z = data(:,4);
figure
plot(x,y);
figure
plot(x,z);
figure
plot(y,z);