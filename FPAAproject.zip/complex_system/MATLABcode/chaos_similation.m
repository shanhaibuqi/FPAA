function chaos_similation()


x0 =  -1 / 1 ;
y0 =   1 / 1 ;
z0 =  -1 / 1 ;

close all;

% initial_values = [-0.25; 0.25; -0.25;];
initial_values = [x0; y0; z0;];
% initial_values = [-1; 1; -1;];

dt=5*10^(-3); 

tspan = (0 :dt: 1000);



a = 1;

b = 1;



% [t,sol] = ode45(@(t,y)ode_system(t,y,a,b),tspan,initial_values);
% 
% x = sol(:,1);
% y = sol(:,2);
% 
% 
% z = sol(:,3);
% for i = 1:1:9
    
sol = ode45(@(t,y)ode_system(t,y,a,b),[tspan(1) tspan(end)],initial_values);
ss = deval(sol,tspan)';
s = ss(30000:end,:);  %去除杂点
% 
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Give phase trajectories
% subplot(1,3,i);
figure;
plot(s(1:end,1),s(1:end,2),'cyan','LineWidth',0.5);  xlabel('X');ylabel('Y');
set(gca,'FontSize',8);
set(gca,'FontName','Eucild');
set(gca,'FontWeight','bold');%字体加粗
set(gcf,'unit','centimeters','position',[10 10 5.3333 4.805]);
set(gca,'Position',[0.15 0.2 0.75 0.678375]);

% % Define the folder where you want to save the figures
%     folder = 'chaos_figures';
%     
%     % Check if the folder exists, if not, create it
%     if ~exist(folder, 'dir')
%        mkdir(folder)
%     end
%     
%     % Save the figure
%     saveas(gcf, fullfile(folder, ['chaos_simulation_', num2str(i), '.fig']));

% hold on;


figure;
plot(s(1:end,1),s(1:end,3),'cyan','LineWidth',0.5);  xlabel('X');ylabel('Z');

set(gca,'FontSize',8);
set(gca,'FontName','Eucild');
set(gca,'FontWeight','bold');%字体加粗
set(gcf,'unit','centimeters','position',[10 10 5.33 4.805]);
set(gca,'Position',[0.20 0.2 0.75 0.678375]);
% axis square

figure;
plot(s(1:end,2),s(1:end,3),'cyan','LineWidth',0.5);  xlabel('Y');ylabel('Z');

set(gca,'FontSize',8);
set(gca,'FontName','Eucild');
set(gca,'FontWeight','bold');%字体加粗
set(gcf,'unit','centimeters','position',[10 10 5.33 4.805]);
set(gca,'Position',[0.20 0.2 0.75 0.678375]);

% figure;
% plot(s(1:end,1),s(1:end,3),'r');  xlabel('X');ylabel('Z')
% figure;
% plot(s(1:end,2),s(1:end,3),'b');  xlabel('Y');ylabel('Z')

% plot(x,y,'Color','b','LineWidth','1.5');  
% xlabel('X');ylabel('Y');
% title('The trajectory diagram of XY');

% set(gca,'LooseInset',get(gca,'TightInset'))

% xlim([-k k]);
% xlim atuo
% box on;

% discard_index = round(0.5 * length(t));
% 
% x = sol(discard_index:end, 1);
% y = sol(discard_index:end, 2);
% z = sol(discard_index:end, 3);
% t = t(discard_index:end);

 

%向轨图
% figure;
% subplot(2,2,1);
% plot(x,z); 
% xlabel('x');
% ylabel('z');
% title('The trajectory diagram of XZ');
% 
% subplot(2,2,2);
% plot(x,y);
% xlabel('x');
% ylabel('y');
% title('The trajectory diagram of XY');
% 
% subplot(2,2,3); 
% plot(y,z);
% xlabel('y');
% ylabel('z');
% title('The trajectory diagram of YZ');
% 
% % subplot(2,2,4);
% % plot3(x,y,z);
% % hold on;
% % [X,Y] = meshgrid(linspace(min(x), max(x), 100), linspace(min(y), max(y), 100));
% % Z = zeros(size(X));%x=0;
% % % Z =-X;
% % surf(Z, X, Y, 'FaceAlpha', 0.5, 'FaceColor', 'r', 'EdgeColor', 'none');
% % hold off;
% 
% 
% % 时序图
% % figure;
% subplot(6,2,8);
% plot(t,k*x);
% xlabel('t');
% ylabel('x');
% title('Time sequence diagram of X');
% 
% subplot(6,2,10);
% plot(t,k*y);
% xlabel('t');
% ylabel('y');
% title('Time sequence diagram of Y');
% 
% subplot(6,2,12);
% plot(t,k*z);
% xlabel('t');
% ylabel('z');
% title('Time sequence diagram of Z');
% % % % % 
% % % % % 
% % % % % plot3(x,y,z);
% figure;
% % dx/dt 时序图
% subplot(2, 2, 1);
% dxdt = gradient(x, t);
% plot(t, dxdt, 'LineWidth', 0.5);
% xlabel('t');
% ylabel('dx/dt');
% title('dx/dt 时序图');
% 
% % dy/dt 时序图
% subplot(2, 2, 2);
% dydt = gradient(y, t);
% plot(t, dydt, 'LineWidth', 0.5);
% xlabel('t');
% ylabel('dy/dt');
% title('dy/dt 时序图');
% 
% % dz/dt 时序图
% subplot(2, 2, 3);
% dzdt = gradient(z, t);
% plot(t, dzdt, 'LineWidth', 0.5);
% xlabel('t');
% ylabel('dz/dt');
% title('dz/dt 时序图');
% 
% end
end