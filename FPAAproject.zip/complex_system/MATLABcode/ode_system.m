function dX = ode_system(~,X,a,b)

% global k1 k2 k3;

x = X(1);
y = X(2);
z = X(3);
% u = X(4);

%sys0_change
k1 = 5 ;
k2 = 6 ;
k3 = 5 ;
dxdt = (a * k2 * k3 *y * z)/k1;
dydt = (1 - b * (5 * z) ^ 2 )/k2;
dzdt = (k1 * x + k2 * k3 * y * z )/k3;

%sys0
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k2 * k3 *y * z)/k1;
% dydt = (1 - b * (k3 * z) ^ 2 )/k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;

%sys1_change
% k1 = 6 ;
% k2 = 8 ;
% k3 = 5 ;
% dxdt = (a * k3 * k2 * y * z)/k1;
% dydt = (1.5 - b * abs((k3 * z) ^ 1.7))/k2;
% dzdt = (k1 * x +  k2 * k3 * y * z)/k3;

%sys1
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k3 * k2 * y * z)/k1;
% dydt = (1.5 - b * abs((k3 * z) ^ 1.7))/k2;
% dzdt = (k1 * x +  k2 * k3 * y * z)/k3;

%sys2_change
% k1 = 5 ;
% k2 = 10 ;
% k3 = 5 ;
% dxdt = (a * k2 * k3 * y * z )/k1;
% dydt = (1.5 - b * exp(abs(k3 * z)))/k2 ;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3;

%sys2 a=1 b=0.4
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k2 * k3 * y * z )/k1;
% dydt = (1.5 - b * exp(abs(k3 * z)))/k2 ;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3;

% sys3_change
% k1 = 6 ; 
% k2 = 10 ;
% k3 = 2 ;
% dxdt = (a * k2 * k3 * y * z)/k1 ;  
% dydt = (1 - b * abs(tan(k3 * z)))/k2;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3;

% sys3 a=3.3 b=7.1
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k2 * k3 * y * z)/k1 ;  
% dydt = (1 - b * abs(tan(k3 * z)))/k2;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3;

%sys4 change
% k1 = 4 ;
% k2 = 3 ;
% k3 = 2 ;
% dxdt = (a * k2 * k3 * y * z)/k1;
% dydt = (1 - b * abs( sin (k3*z) ))/k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;

%sys4 a=3.3 b=7.5
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k2 * k3 * y * z)/k1;
% dydt = (1 - b * abs( sin (k3*z) ))/k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;

% sys5_change
% k1 = 10 ;
% k2 = 10 ;
% k3 = 5 ;
% dxdt = (a * k2 * k3 * y * z)/k1 ;
% dydt = (1 -  b * ((sin(k3 * z)) ^ 2))/k2 ;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3 ;

%sys5 a=5 b =10
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1;
% dxdt = (a * k2 * k3 * y * z)/k1 ;
% dydt = (1 -  b * ((sin(k3 * z)) ^ 2))/k2 ;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3 ;

%sys6_change
% k1 = 5;
% k2 = 3;
% k3 = 2;
% dxdt = (a * k2 * y * k3 * z)/k1;
% dydt = (1 - b * sign(k3 * z)* tanh(k3 * z))/k2;
% dzdt = (k1 * x + k2 * y * k3 * z)/k3;

%sys6 a=3.1 b=8
% k1 = 1;
% k2 = 1;
% k3 = 1;
% dxdt = (a * k2 * y * k3 * z)/k1;
% dydt = (1 - b * sign(k3 * z)* tanh(k3 * z))/k2;
% dzdt = (k1 * x + k2 * y * k3 * z)/k3;

%sys7_change
% k1 = 2;
% k2 = 3;
% k3 = 2;
% dxdt = (a * k2 * k3 * y * z )/k1;
% dydt = (1 - b * cosh(k3 * z) + 0.2 )/k2;
% dzdt = (k3 * x + k2 * k3 * y * z )/k3;

%sys7
% k1 = 1;
% k2 = 1;
% k3 = 1;
% dxdt = (a * k2 * k3 * y * z )/k1;
% dydt = (1 - cosh(k3 * z) + 0.2 )/k2;
% dzdt = (k3 * x + k2 * k3 * y * z )/k3;

%sys8_change
%x>4x,y>6y,z>4z
%z>3z,开始周期化,sinh函数缩放不理想
% k1 = 4 ;
% k2 = 5 ;
% k3 = 4 ;
% dxdt = (a * k3 * k2 * y * z )/k1;
% dydt = (1.5 - b * abs( sinh (k3 * z) ) ) / k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;
%
% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k3 * k2 * y * z )/k1;
% dydt = (1.5 - b * sign(k3 * z) * sinh (k3 * z) )  / k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;
%
% k1 = 3 ;
% k2 = 5 ;
% k3 = 4 ;
% dxdt = (a * k3 * k2 * y * z )/k1;
% dydt = (1.1 - b * abs( sinh (k3 * z) ) ) / k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;
%
%sys8
% k1 = 1;
% k2 = 1;
% k3 = 1;
% dxdt = (a * k3 * k2 * y * z )/k1;
% dydt = (1.1 - b *  abs( (sinh (k3 * z) ) ) )/ k2;
% dzdt = (k1 * x + k2 * k3 * y * z )/k3;

% x>10x,y>5y,z>2z
% dxdt = 0.1 * (10 * a * y * z) ;
% dydt = 0.2 * ( 1 -  b * abs((sin(2*z)) ^ 2) );
% dzdt = 0.5 * (10 * x + 10 * y * z) ;

% k1 = 1 ;
% k2 = 1 ;
% k3 = 1 ;
% dxdt = (a * k2 * y * k1 * z)/k1 ;
% dydt = (1.3 - b * abs(k3 * z) ^ (abs(1.6 * sin(k3 * z))) - 0.8 * k3 * z)/k2;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3;

%a=1.1 b=1
% k1 = 10 ;
% k2 = 20 ;
% k3 = 10 ;
% dxdt = (a * k2 * k3 * y * z)/k1;
% dydt = (1.5 - b  * (abs(k3 * z) )^ (k3 * z) + 0.7 * k3 * z)/k2;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3 ;

% dxdt = a * y * z ;
% dydt = 2.1 - b  * abs(z) ^ (abs(z)) + 1 * u;
% dzdt = x + y * z ;
% dudt = 0.1 * x;

% k1 = 2;
% k2 = 5;
% k3 = 2;
% dxdt = (a * k2 * y * k3 * z)/k1 ;
% dydt = (1 - b * abs( k3 * z * k1 * x))/k2 ;
% dzdt = (k1 * x + k2 * k3 * y * z)/k3 ;



dX = [dxdt ;dydt ;dzdt;];

end
