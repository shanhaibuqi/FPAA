#ifndef CAMCODE_H
#define CAMCODE_H

#include "ApiCode.h"

/********************************************************************\
*                      AnadigmDesigner2 C Code                       *
*--------------------------------------------------------------------*
*                                                                    *
*  File:      CAMCode.h                                              *
*  Circuit:   sys1.ad2                                               *
*  Generated: April 11, 2025:  07:58 PM                              *
*  Version:   2.8.0.10 -  (Standard) - Release                       *
*  Copyright: Copyright � 2002 Anadigm. All rights reserved.         *
*                                                                    *
\********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*##################################################################*\
#                                                                    #
#                            GainHalf.cam                            #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                               Gain                               (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                       fixed_setGainHalf                        |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_fixed_setGainHalf(an_CAM cam, double G);             
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full fixed-point method for setting the gain of the module. |
  |  It accepts floating-point inputs and returns a floating-point |
  |  result.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf1           an_system1_GainHalf1 an_system1           |
  |  GainHalf1           an_system1_ic_GainHalf1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                          setGainHalf                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setGainHalf(an_CAM cam, double G);                   
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating point method for setting the gain of this     |
  |  module.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf1           an_system1_GainHalf1 an_system1           |
  |  GainHalf1           an_system1_ic_GainHalf1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                           Integrator.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Integrator                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                         setIntegrator                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setIntegrator(an_CAM cam, double K);                 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the Integration      |
  |  constant (in 1/microseconds) of this module.                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Integrator4         an_system2_Integrator4 an_system2         |
  |  Integrator5         an_system2_Integrator5 an_system2         |
  |  Integrator6         an_system2_Integrator6 an_system2         |
  |  Integrator1         an_system2_ic_Integrator1 an_system2_ic      |
  |  Integrator2         an_system2_ic_Integrator2 an_system2_ic      |
  |  Integrator3         an_system2_ic_Integrator3 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                           Multiplier.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Multiplier                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                      fixedp_setMultiplier                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_fixedp_setMultiplier(an_CAM cam, double M);          
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the multiplication factor of |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier2         an_system1_Multiplier2 an_system1         |
  |  Multiplier1         an_system1_ic_Multiplier1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                         setMultiplier                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     double an_setMultiplier(an_CAM cam, double M);                 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the multiplication   |
  |  factor of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier2         an_system1_Multiplier2 an_system1         |
  |  Multiplier1         an_system1_ic_Multiplier1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                            SumDiff.cam                             #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                             SumDiff                              (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                   fixedp_setGainSumDiff_2in                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_fixedp_setGainSumDiff_2in(an_CAM cam, double G1, double G2); 
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the gain of the inputs of    |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff3            an_system1_SumDiff3 an_system1            |
  |  SumDiff4            an_system1_SumDiff4 an_system1            |
  |  SumDiff1            an_system1_ic_SumDiff1 an_system1_ic      |
  |  SumDiff2            an_system1_ic_SumDiff2 an_system1_ic      |
  |  SumDiff5            an_system2_SumDiff5 an_system2            |
  |  SumDiff6            an_system2_SumDiff6 an_system2            |
  |  SumDiff7            an_system2_SumDiff7 an_system2            |
  |  SumDiff2            an_system2_ic_SumDiff2 an_system2_ic      |
  |  SumDiff3            an_system2_ic_SumDiff3 an_system2_ic      |
  |  SumDiff4            an_system2_ic_SumDiff4 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

  /*--------------------------------------------------------------*\
  |                       setGainSumDiff_2in                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_setGainSumDiff_2in(an_CAM cam, double G1, double G2);  
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the gain of the      |
  |  inputs of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff3            an_system1_SumDiff3 an_system1            |
  |  SumDiff4            an_system1_SumDiff4 an_system1            |
  |  SumDiff1            an_system1_ic_SumDiff1 an_system1_ic      |
  |  SumDiff2            an_system1_ic_SumDiff2 an_system1_ic      |
  |  SumDiff5            an_system2_SumDiff5 an_system2            |
  |  SumDiff6            an_system2_SumDiff6 an_system2            |
  |  SumDiff7            an_system2_SumDiff7 an_system2            |
  |  SumDiff2            an_system2_ic_SumDiff2 an_system2_ic      |
  |  SumDiff3            an_system2_ic_SumDiff3 an_system2_ic      |
  |  SumDiff4            an_system2_ic_SumDiff4 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/


/*##################################################################*\
#                                                                    #
#                        TransferFunction.cam                        #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                    Transfer Function Control                     (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                    setTransferFunctionTable                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Function Declaration                                          |
  \*  ------------------------------                              */
     void an_setTransferFunctionTable(an_CAM cam, double* Values);  
  /*                                                              *\
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function sets up the Transfer Function values for        |
  |  operation over input voltage. It assumes the input table has  |
  |  256 entries.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  TransferFunction2   an_system1_TransferFunction2 an_system1         |
  |  TransferFunction1   an_system1_ic_TransferFunction1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif /* CAMCODE_H */
