#include "CAMCode.h"

/********************************************************************\
*                      AnadigmDesigner2 C Code                       *
*--------------------------------------------------------------------*
*                                                                    *
*  File:      CAMCode.c                                              *
*  Circuit:   sys1.ad2                                               *
*  Generated: April 11, 2025:  07:58 PM                              *
*  Version:   2.8.0.10 -  (Standard) - Release                       *
*  Copyright: Copyright � 2002 Anadigm. All rights reserved.         *
*                                                                    *
\********************************************************************/

/*##################################################################*\
#                                                                    #
#                            GainHalf.cam                            #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                               Gain                               (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                       fixed_setGainHalf                        |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full fixed-point method for setting the gain of the module. |
  |  It accepts floating-point inputs and returns a floating-point |
  |  result.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf1           an_system1_GainHalf1 an_system1           |
  |  GainHalf1           an_system1_ic_GainHalf1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     double an_fixed_setGainHalf(an_CAM cam, double G)
     {
        an_Byte cap1;
        an_Byte cap2;
        
        an_FixedChooseCapRatio(G, &cap1, &cap2);
        
        an_SetCapValue(cam, an_AnadigmApex_GainHalf_Cin,cap1);
        an_SetCapValue(cam, an_AnadigmApex_GainHalf_Cout,cap2);
        return an_FixedToFloat(an_FixedDivide(an_IntToFixed(cap1),an_IntToFixed(cap2)));
     }

  /*--------------------------------------------------------------*\
  |                          setGainHalf                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating point method for setting the gain of this     |
  |  module.                                                       |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  GainHalf1           an_system1_GainHalf1 an_system1           |
  |  GainHalf1           an_system1_ic_GainHalf1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     double an_setGainHalf(an_CAM cam, double G)
     {
        an_Byte cap1;
        an_Byte cap2;
        
        an_ChooseCapRatio(G, &cap1, &cap2);
        
        an_SetCapValue(cam, an_AnadigmApex_GainHalf_Cin,cap1);
        an_SetCapValue(cam, an_AnadigmApex_GainHalf_Cout,cap2);
        return (double) cap1 / (double) cap2;
     }


/*##################################################################*\
#                                                                    #
#                           Integrator.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Integrator                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                         setIntegrator                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the Integration      |
  |  constant (in 1/microseconds) of this module.                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Integrator4         an_system2_Integrator4 an_system2         |
  |  Integrator5         an_system2_Integrator5 an_system2         |
  |  Integrator6         an_system2_Integrator6 an_system2         |
  |  Integrator1         an_system2_ic_Integrator1 an_system2_ic      |
  |  Integrator2         an_system2_ic_Integrator2 an_system2_ic      |
  |  Integrator3         an_system2_ic_Integrator3 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     double an_setIntegrator(an_CAM cam, double K)
     {
        double aK;
        int C1 = 1, C2 = 1;
        int dC1, dC2 = 255;
        double err = 99999.9;
        double errtemp = 999.9;
        double FCM = an_GetApexClockFrequency(cam, an_CAMClock_ClockA) / 1000000.0;
        
        while ( dC2 > 0 )
        {
           dC1 = an_AdjustCap(K * dC2 / FCM);
           aK = dC1 * FCM / dC2;
           errtemp = fabs( (K - aK) / K);
           if (errtemp < err)
           {
              err = errtemp;
              C1 = dC1;
              C2 = dC2;
           }
           dC2--;
        }
        
        aK = FCM * C1/C2;
        
        an_SetCapValue(cam, an_AnadigmApex_Integrator_Cin, C1);
        an_SetCapValue(cam, an_AnadigmApex_Integrator_Cint, C2);
        
        return aK;
     }


/*##################################################################*\
#                                                                    #
#                           Multiplier.cam                           #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                            Multiplier                            (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                      fixedp_setMultiplier                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the multiplication factor of |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier2         an_system1_Multiplier2 an_system1         |
  |  Multiplier1         an_system1_ic_Multiplier1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     double an_fixedp_setMultiplier(an_CAM cam, double M)
     {
        double aM;
        int C1 = 85, C2 = an_FixedToInt(an_FixedDivide(an_IntToFixed(C1),an_FloatToFixed(M)));
        
        an_SetCapValue(cam, an_AnadigmApex_Multiplier_Cin, C1);
        an_SetCapValue(cam, an_AnadigmApex_Multiplier_Cout, C2);
        
        aM = 1.0 * C1/C2;
        
        return aM;
     }

  /*--------------------------------------------------------------*\
  |                         setMultiplier                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the multiplication   |
  |  factor of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  Multiplier2         an_system1_Multiplier2 an_system1         |
  |  Multiplier1         an_system1_ic_Multiplier1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     double an_setMultiplier(an_CAM cam, double M)
     {
        double aM;
        int C1 =85, C2 = floor(C1 / M + 0.5);
        
        an_SetCapValue(cam, an_AnadigmApex_Multiplier_Cin, C1);
        an_SetCapValue(cam, an_AnadigmApex_Multiplier_Cout, C2);
        
        aM = 1.0 * C1/C2;
        
        return aM;
     }


/*##################################################################*\
#                                                                    #
#                            SumDiff.cam                             #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                             SumDiff                              (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                   fixedp_setGainSumDiff_2in                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A fixed-point method for setting the gain of the inputs of    |
  |  this module.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff3            an_system1_SumDiff3 an_system1            |
  |  SumDiff4            an_system1_SumDiff4 an_system1            |
  |  SumDiff1            an_system1_ic_SumDiff1 an_system1_ic      |
  |  SumDiff2            an_system1_ic_SumDiff2 an_system1_ic      |
  |  SumDiff5            an_system2_SumDiff5 an_system2            |
  |  SumDiff6            an_system2_SumDiff6 an_system2            |
  |  SumDiff7            an_system2_SumDiff7 an_system2            |
  |  SumDiff2            an_system2_ic_SumDiff2 an_system2_ic      |
  |  SumDiff3            an_system2_ic_SumDiff3 an_system2_ic      |
  |  SumDiff4            an_system2_ic_SumDiff4 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_fixedp_setGainSumDiff_2in(an_CAM cam, double G1, double G2)
     {
        an_Fixed aG1, aG2;
        an_Fixed workG1 = an_FloatToFixed(G1);
        an_Fixed workG2 = an_FloatToFixed(G2);
        int C1=1, C2=1, Cout=1;
        int dC1=255, dC2=255, dCout=255;
        an_Fixed err;
        an_Fixed bestErr = 0x7FFFFFFF;
        an_Fixed fixedp_dCout;
        short Z1=0, Z2=0;
        if (workG1==0)	Z1=1;
        if (workG2==0)	Z2=1;
        
        while (dCout > 0)
        {	err = 0;
                fixedp_dCout = an_IntToFixed(dCout);
           if (Z1==0)
           {	dC1 = an_FixedAdjustCap(an_FixedMultiply(workG1,fixedp_dCout));
              aG1 = an_FixedDivide(an_IntToFixed(dC1),fixedp_dCout);
              err += an_FixedDivide(aG1,workG1) + an_FixedDivide(workG1,aG1);
           }
           if (Z2==0)
           {	dC2 = an_FixedAdjustCap(an_FixedMultiply(workG2,fixedp_dCout));
              aG2 = an_FixedDivide(an_IntToFixed(dC2),fixedp_dCout);
              err += an_FixedDivide(aG2,workG2) + an_FixedDivide(workG2,aG2);
           }
           if (err < bestErr)
           {
              bestErr = err;
              C1 = dC1;
              C2 = dC2;
              Cout = dCout;
           }
           dCout--;
        }
        if (Z1==1)	C1=0;
        if (Z2==1)	C2=0;
        
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_CinA, C1);
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_CinB, C2);
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_Cout, Cout);
     }

  /*--------------------------------------------------------------*\
  |                       setGainSumDiff_2in                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  A full floating-point method for setting the gain of the      |
  |  inputs of this module.                                        |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  SumDiff3            an_system1_SumDiff3 an_system1            |
  |  SumDiff4            an_system1_SumDiff4 an_system1            |
  |  SumDiff1            an_system1_ic_SumDiff1 an_system1_ic      |
  |  SumDiff2            an_system1_ic_SumDiff2 an_system1_ic      |
  |  SumDiff5            an_system2_SumDiff5 an_system2            |
  |  SumDiff6            an_system2_SumDiff6 an_system2            |
  |  SumDiff7            an_system2_SumDiff7 an_system2            |
  |  SumDiff2            an_system2_ic_SumDiff2 an_system2_ic      |
  |  SumDiff3            an_system2_ic_SumDiff3 an_system2_ic      |
  |  SumDiff4            an_system2_ic_SumDiff4 an_system2_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_setGainSumDiff_2in(an_CAM cam, double G1, double G2)
     {
        double aG1, aG2;
        int C1=1, C2=1, Cout=1;
        int dC1=255, dC2=255, dCout=255;
        double err = 99999;
        double bestErr = 999;
        short Z1=0, Z2=0;
        if (G1==0)	Z1=1;
        if (G2==0)	Z2=1;
        
        while (dCout > 0)
        {	err = 0;
           if (Z1==0)
           {	dC1 = an_AdjustCap(G1*dCout);
              aG1 = 1.0 * dC1/dCout;
              err += aG1/G1 + G1/aG1;
           }
           if (Z2==0)
           {	dC2 = an_AdjustCap(G2*dCout);
              aG2 = 1.0 * dC2/dCout;
              err += aG2/G2 + G2/aG2;
           }
           if (err < bestErr)
           {
              bestErr = err;
              C1 = dC1;
              C2 = dC2;
              Cout = dCout;
           }
           dCout--;
        }
        if (Z1==1)	C1=0;
        if (Z2==1)	C2=0;
        
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_CinA, C1);
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_CinB, C2);
        an_SetCapValue(cam, an_AnadigmApex_SumDiff_Cout, Cout);
     }


/*##################################################################*\
#                                                                    #
#                        TransferFunction.cam                        #
#                                                                    #
\*##################################################################*/

 /*================================================================*\
 )                    Transfer Function Control                     (
 \*================================================================*/

  /*--------------------------------------------------------------*\
  |                    setTransferFunctionTable                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function sets up the Transfer Function values for        |
  |  operation over input voltage. It assumes the input table has  |
  |  256 entries.                                                  |
  |                                                                |
  |                                                                |
  |  Instance Name       cam                 chip                  |
  |  ------------------------------------------------------------  |
  |  TransferFunction2   an_system1_TransferFunction2 an_system1         |
  |  TransferFunction1   an_system1_ic_TransferFunction1 an_system1_ic      |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_setTransferFunctionTable(an_CAM cam, double* Values)
     {
        an_Byte LUTTable[256];
        int loop;
        double maxV = 0.0;
        int C1 = 128, C2 = 128;
        
        for (loop = 0; loop < 256; loop++)
           if (maxV < fabs(Values[loop]))
              maxV = fabs(Values[loop]);
        if (maxV > 0.0)
           C2 = an_AdjustCap(127.0*2.0/maxV);
        
        for (loop = 0; loop < 256; loop++)
        {
           C1 = an_AdjustCap(128.0 + Values[loop]*C2/2.0);
           LUTTable[loop] = (an_Byte)C1;
        }
        an_LoadLUT(cam, LUTTable, 0, 256);
        an_SetCapValue(cam, an_AnadigmApex_TransferFunction_Cout, C2);
     }


