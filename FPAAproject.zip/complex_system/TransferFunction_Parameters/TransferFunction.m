
x1 = linspace(-3, 3, 256);

y1 = zeros(1, 256);

for i = 1:256
    y1(i) = 0.2 * sign(4*x1(i))*sinh(4*x1(i));
%         y1(i) = 0.1 * abs((5 * x1(i)) ^ 1.7);
%         y1(i) = 0.04 * exp(abs(5 * x1(i)));
%sys0
%        y1(i) = 25 * x1(i) * x1(i) ;
%
%         y1(i) = 0.1 * 0.71 * abs( tan(2*x1(i)) );
%         y1(i) = 0.498 * abs(tan(1.2 * x1(i)));
%         y1(i) = (sin(5 * x1(i))) ^ 2;
%         y1(i) = cosh(2*x1(i))/15;

%         y1(i) = (( (abs( 10 * x1(i) ) ) ^ (10 * x1(i))) + 7 * x1(i))/60;
%     y1(i) = sin(5 * x1(i)) ^ 2;
%          y1(i) = 0.1 * abs( sinh (5 * x1(i)) );
%     if(abs(y1(i))>=3.3)
%         y1(i) = 3.3;
%     end
end

% save
data = [y1' x1'];
writematrix(data, 'cosh2x.csv');