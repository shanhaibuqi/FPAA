#include "stdafx.h"
#include "systemB_IC_Integrator2.h"

systemB_IC_Integrator2::systemB_IC_Integrator2()
{
   m_instance = an_systemB_IC_Integrator2;
}

//-----------------------------------------------------------
//  A full floating-point method for setting the Integration      
//  constant (in 1/microseconds) of this module.                  
//-----------------------------------------------------------
double systemB_IC_Integrator2::setIntegrator(double K)
{
   return an_setIntegrator(m_instance, K);
}

