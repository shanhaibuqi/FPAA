#pragma once

class systemB_Integrator5
{
public:
   systemB_Integrator5();

   //-----------------------------------------------------------
   //  A full floating-point method for setting the Integration      
   //  constant (in 1/microseconds) of this module.                  
   //-----------------------------------------------------------
   double setIntegrator(double K);

private:
   an_CAM m_instance;
};
