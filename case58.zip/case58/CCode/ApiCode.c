#include "ApiCode.h"

/********************************************************************\
*                      AnadigmDesigner2 C Code                       *
*--------------------------------------------------------------------*
*                                                                    *
*  File:      ApiCode.c                                              *
*  Circuit:   case58.ad2                                             *
*  Generated: October 20, 2024:  03:52 PM                            *
*  Version:   2.8.0.10 -  (Standard) - Release                       *
*  Copyright: Copyright � 2002 Anadigm. All rights reserved.         *
*                                                                    *
\********************************************************************/

/*##################################################################*\
#                                                                    #
#                        Data and Definitions                        #
#                                                                    #
\*##################################################################*/

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h file to the chip's Address1. */                           
const an_Byte an_apiAddress1[an_apiChipCount] =
{
   0x01,                /* an_systemA: 00000001 */
   0x01,                /* an_systemA_IC: 00000001 */
   0x02,                /* an_systemB: 00000010 */
   0x02                 /* an_systemB_IC: 00000010 */
};

/* This is the initial full configuration stream for systemA. */
const an_Byte an_systemA_PrimaryConfigInfo[] = 
{
   /* The header for the configuration stream */
   0xD5, /* Synch     */
   0xB7, /* JTAG0     */
   0x20, /* JTAG1     */
   0x01, /* JTAG2     */
   0x00, /* JTAG3     */
   0x01, /* Address1  */
   0xC1, /* Control   */

   /* Start of data block */
   0xC4, /* Byte address:  4 */
   0x00, /* Bank address:  0 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x20,  0x08,  0x00,  0x02,  0x19,  0x00,  0x00,  0x40,  
   0x00,  0x00,  0x15,  0xFF,  0x0F,  0xF1,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC2, /* Byte address:  2 */
   0x01, /* Bank address:  1 */
   0x01, /* Byte count:    1 */

   /* Data bytes for block */
   0x40,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xDE, /* Byte address: 30 */
   0x01, /* Bank address:  1 */
   0x19, /* Byte count:   25 */

   /* Data bytes for block */
   0x02,  0xFF,  0xC0,  0x50,  0x00,  0x06,  0xC8,  0x05,  
   0x00,  0x56,  0x00,  0x00,  0x40,  0x00,  0x00,  0x10,  
   0x00,  0x00,  0x40,  0x00,  0x00,  0x40,  0x08,  0x08,  
   0x08,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC0, /* Byte address:  0 */
   0x03, /* Bank address:  3 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x80,  0xAA,  0x00,  0xFF,  0x55,  0x55,  0xFF,  0x55,  
   0x04,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xCF, /* Byte address: 15 */
   0x03, /* Bank address:  3 */
   0x39, /* Byte count:   57 */

   /* Data bytes for block */
   0xC8,  0x05,  0x14,  0x2D,  0x48,  0x00,  0x00,  0x00,  
   0x00,  0x06,  0x17,  0x00,  0x20,  0x02,  0x71,  0x00,  
   0x10,  0xED,  0x00,  0x00,  0x00,  0x01,  0x02,  0x00,  
   0x00,  0x00,  0x1B,  0x00,  0x03,  0x01,  0x17,  0x01,  
   0x48,  0x02,  0x12,  0x00,  0x20,  0x82,  0x05,  0x02,  
   0x13,  0x00,  0x10,  0x82,  0x05,  0x02,  0x61,  0x00,  
   0x10,  0x00,  0x00,  0x00,  0x00,  0xFF,  0xFF,  0xFF,  
   0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD9, /* Byte address: 25 */
   0x05, /* Bank address:  5 */
   0x08, /* Byte count:    8 */

   /* Data bytes for block */
   0x20,  0x01,  0x82,  0x00,  0x30,  0x01,  0x81,  0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD5, /* Byte address: 21 */
   0x06, /* Bank address:  6 */
   0x14, /* Byte count:   20 */

   /* Data bytes for block */
   0x05,  0x01,  0x2B,  0x01,  0x28,  0x00,  0x05,  0x01,  
   0x3E,  0x01,  0x18,  0x80,  0xAA,  0xFF,  0x55,  0x17,  
   0x02,  0x8A,  0x5C,  0x02,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xCF, /* Byte address: 15 */
   0x07, /* Bank address:  7 */
   0x39, /* Byte count:   57 */

   /* Data bytes for block */
   0xC8,  0x05,  0x14,  0x2D,  0x48,  0x02,  0x12,  0x00,  
   0x20,  0x02,  0x31,  0x00,  0x10,  0x02,  0x16,  0x00,  
   0x10,  0xED,  0x00,  0x10,  0x00,  0x02,  0x01,  0x00,  
   0x00,  0x00,  0x1B,  0x00,  0x03,  0x01,  0x16,  0x01,  
   0x48,  0x06,  0x17,  0x00,  0x20,  0x82,  0x05,  0x02,  
   0x51,  0x00,  0x10,  0x42,  0x05,  0x02,  0x1A,  0x00,  
   0x10,  0x00,  0x00,  0x00,  0x00,  0xFA,  0xFF,  0xFF,  
   0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x09, /* Bank address:  9 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x01,  0x12,  0x00,  0x20,  0x00,  0x30,  0x01,  0x18,  
   0x0E,  0x00,  0x00,  0x00,  0x00,  0x01,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0x94, /* Byte address: 20 */
   0x0A, /* Bank address: 10 */
   0x0C, /* Byte count:   12 */

   /* Data bytes for block */
   0x81,  0x05,  0x01,  0x17,  0x00,  0x20,  0x00,  0x05,  
   0x01,  0xD3,  0x01,  0x81,  

   /* Check Byte: Inverse Synch */
   0x2A
};

/* This is the initial full configuration stream for systemA_IC. */
const an_Byte an_systemA_IC_PrimaryConfigInfo[] = 
{
   /* The header for the configuration stream */
   0xD5, /* Synch     */
   0xB7, /* JTAG0     */
   0x20, /* JTAG1     */
   0x01, /* JTAG2     */
   0x00, /* JTAG3     */
   0x01, /* Address1  */
   0xC1, /* Control   */

   /* Start of data block */
   0xC4, /* Byte address:  4 */
   0x00, /* Bank address:  0 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x20,  0x08,  0x00,  0x02,  0x19,  0x00,  0x00,  0x40,  
   0x00,  0x00,  0x15,  0xFF,  0x0F,  0xF1,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC2, /* Byte address:  2 */
   0x01, /* Bank address:  1 */
   0x01, /* Byte count:    1 */

   /* Data bytes for block */
   0x40,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xDE, /* Byte address: 30 */
   0x01, /* Bank address:  1 */
   0x19, /* Byte count:   25 */

   /* Data bytes for block */
   0x02,  0xFF,  0xC0,  0x50,  0x00,  0x06,  0xC8,  0x05,  
   0x00,  0x56,  0x00,  0x00,  0x40,  0x00,  0x00,  0x10,  
   0x00,  0x00,  0x40,  0x00,  0x00,  0x40,  0x08,  0x08,  
   0x08,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC0, /* Byte address:  0 */
   0x03, /* Bank address:  3 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x80,  0xAA,  0x00,  0xFF,  0x55,  0x55,  0xFF,  0x55,  
   0x04,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xCF, /* Byte address: 15 */
   0x03, /* Bank address:  3 */
   0x39, /* Byte count:   57 */

   /* Data bytes for block */
   0xC8,  0x05,  0x14,  0x2D,  0x48,  0x00,  0x00,  0x00,  
   0x00,  0x06,  0x17,  0x00,  0x20,  0x02,  0x71,  0x00,  
   0x10,  0xED,  0x00,  0x00,  0x00,  0x01,  0x02,  0x00,  
   0x00,  0x00,  0x1B,  0x00,  0x03,  0x01,  0x17,  0x01,  
   0x48,  0x02,  0x12,  0x00,  0x20,  0x82,  0x05,  0x02,  
   0x13,  0x00,  0x10,  0x82,  0x05,  0x02,  0x61,  0x00,  
   0x10,  0x00,  0x00,  0x00,  0x00,  0xFF,  0xFF,  0xFF,  
   0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD9, /* Byte address: 25 */
   0x05, /* Bank address:  5 */
   0x08, /* Byte count:    8 */

   /* Data bytes for block */
   0x20,  0x01,  0x82,  0x00,  0x30,  0x01,  0x81,  0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD5, /* Byte address: 21 */
   0x06, /* Bank address:  6 */
   0x14, /* Byte count:   20 */

   /* Data bytes for block */
   0x05,  0x01,  0x2B,  0x01,  0x28,  0x00,  0x05,  0x01,  
   0x3E,  0x01,  0x18,  0x80,  0xAA,  0xFF,  0x55,  0x17,  
   0x02,  0x8A,  0x5C,  0x02,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xCF, /* Byte address: 15 */
   0x07, /* Bank address:  7 */
   0x39, /* Byte count:   57 */

   /* Data bytes for block */
   0xC8,  0x05,  0x14,  0x2D,  0x48,  0x02,  0x12,  0x00,  
   0x20,  0x02,  0x31,  0x00,  0x10,  0x02,  0x16,  0x00,  
   0x10,  0xED,  0x00,  0x10,  0x00,  0x02,  0x01,  0x00,  
   0x00,  0x00,  0x1B,  0x00,  0x03,  0x01,  0x16,  0x01,  
   0x48,  0x06,  0x17,  0x00,  0x20,  0x82,  0x05,  0x02,  
   0x51,  0x00,  0x10,  0x42,  0x05,  0x02,  0x1A,  0x00,  
   0x10,  0x00,  0x00,  0x00,  0x00,  0xFA,  0xFF,  0xFF,  
   0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x09, /* Bank address:  9 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x01,  0x12,  0x00,  0x20,  0x00,  0x30,  0x01,  0x18,  
   0x0E,  0x00,  0x00,  0x00,  0x00,  0x01,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0x94, /* Byte address: 20 */
   0x0A, /* Bank address: 10 */
   0x0C, /* Byte count:   12 */

   /* Data bytes for block */
   0x81,  0x05,  0x01,  0x17,  0x00,  0x20,  0x00,  0x05,  
   0x01,  0xD3,  0x01,  0x81,  

   /* Check Byte: Inverse Synch */
   0x2A
};

/* This is the initial full configuration stream for systemB. */
const an_Byte an_systemB_PrimaryConfigInfo[] = 
{
   /* The header for the configuration stream */
   0xD5, /* Synch     */
   0xB7, /* JTAG0     */
   0x20, /* JTAG1     */
   0x01, /* JTAG2     */
   0x00, /* JTAG3     */
   0x02, /* Address1  */
   0xC1, /* Control   */

   /* Start of data block */
   0xC4, /* Byte address:  4 */
   0x00, /* Bank address:  0 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x20,  0x08,  0x00,  0x02,  0x19,  0x00,  0x00,  0x40,  
   0x00,  0x00,  0x15,  0xFF,  0x0F,  0xF1,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC2, /* Byte address:  2 */
   0x01, /* Bank address:  1 */
   0x01, /* Byte count:    1 */

   /* Data bytes for block */
   0x40,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xDE, /* Byte address: 30 */
   0x01, /* Bank address:  1 */
   0x19, /* Byte count:   25 */

   /* Data bytes for block */
   0x02,  0xFF,  0x80,  0x51,  0x00,  0x00,  0x80,  0x10,  
   0x08,  0x01,  0x00,  0x00,  0x40,  0x00,  0x00,  0x10,  
   0x00,  0x00,  0x40,  0x00,  0x00,  0x40,  0x08,  0x08,  
   0x08,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC3, /* Byte address:  3 */
   0x03, /* Bank address:  3 */
   0x05, /* Byte count:    5 */

   /* Data bytes for block */
   0xC8,  0x02,  0xFA,  0xFA,  0x19,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x03, /* Bank address:  3 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x01,  0x19,  0x01,  0x28,  0x01,  0x10,  0x00,  0x10,  
   0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD1, /* Byte address: 17 */
   0x04, /* Bank address:  4 */
   0x17, /* Byte count:   23 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  0x00,  
   0x00,  0x00,  0xC8,  0x02,  0xFF,  0xFF,  0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x05, /* Bank address:  5 */
   0x0B, /* Byte count:   11 */

   /* Data bytes for block */
   0x01,  0x19,  0x01,  0x28,  0x01,  0x10,  0x00,  0x10,  
   0x0E,  0x00,  0x02,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD1, /* Byte address: 17 */
   0x06, /* Bank address:  6 */
   0x0F, /* Byte count:   15 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC3, /* Byte address:  3 */
   0x09, /* Bank address:  9 */
   0x05, /* Byte count:    5 */

   /* Data bytes for block */
   0xC8,  0x02,  0xFC,  0xFC,  0x15,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x09, /* Bank address:  9 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x01,  0x1F,  0x01,  0x28,  0x01,  0x10,  0x00,  0x10,  
   0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0x91, /* Byte address: 17 */
   0x0A, /* Bank address: 10 */
   0x0F, /* Byte count:   15 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  

   /* Check Byte: Inverse Synch */
   0x2A
};

/* This is the initial full configuration stream for systemB_IC. */
const an_Byte an_systemB_IC_PrimaryConfigInfo[] = 
{
   /* The header for the configuration stream */
   0xD5, /* Synch     */
   0xB7, /* JTAG0     */
   0x20, /* JTAG1     */
   0x01, /* JTAG2     */
   0x00, /* JTAG3     */
   0x02, /* Address1  */
   0xC1, /* Control   */

   /* Start of data block */
   0xC4, /* Byte address:  4 */
   0x00, /* Bank address:  0 */
   0x0E, /* Byte count:   14 */

   /* Data bytes for block */
   0x20,  0x08,  0x00,  0x02,  0x19,  0x00,  0x00,  0x40,  
   0x00,  0x00,  0x15,  0xFF,  0x0F,  0xF1,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC2, /* Byte address:  2 */
   0x01, /* Bank address:  1 */
   0x01, /* Byte count:    1 */

   /* Data bytes for block */
   0x40,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xDE, /* Byte address: 30 */
   0x01, /* Bank address:  1 */
   0x04, /* Byte count:    4 */

   /* Data bytes for block */
   0x02,  0xFF,  0x00,  0x80,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xCA, /* Byte address: 10 */
   0x02, /* Bank address:  2 */
   0x0D, /* Byte count:   13 */

   /* Data bytes for block */
   0x40,  0x00,  0x00,  0x10,  0x00,  0x00,  0x40,  0x00,  
   0x00,  0x40,  0x08,  0x08,  0x08,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC3, /* Byte address:  3 */
   0x03, /* Bank address:  3 */
   0x05, /* Byte count:    5 */

   /* Data bytes for block */
   0xC8,  0x02,  0xFC,  0xFC,  0x15,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x03, /* Bank address:  3 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x01,  0x13,  0x01,  0x28,  0x01,  0x12,  0x00,  0x10,  
   0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD1, /* Byte address: 17 */
   0x04, /* Bank address:  4 */
   0x17, /* Byte count:   23 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  0x00,  
   0x00,  0x00,  0xC8,  0x02,  0xFA,  0xFA,  0x19,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x05, /* Bank address:  5 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x01,  0x10,  0x01,  0x28,  0x01,  0x12,  0x00,  0x10,  
   0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD1, /* Byte address: 17 */
   0x06, /* Bank address:  6 */
   0x0F, /* Byte count:   15 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xC3, /* Byte address:  3 */
   0x09, /* Bank address:  9 */
   0x05, /* Byte count:    5 */

   /* Data bytes for block */
   0xC8,  0x02,  0xFF,  0xFF,  0xFF,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0xD8, /* Byte address: 24 */
   0x09, /* Bank address:  9 */
   0x09, /* Byte count:    9 */

   /* Data bytes for block */
   0x01,  0x10,  0x01,  0x28,  0x01,  0x12,  0x00,  0x10,  
   0x0E,  

   /* Check Byte: Inverse Synch */
   0x2A,

   /* Start of data block */
   0x91, /* Byte address: 17 */
   0x0A, /* Bank address: 10 */
   0x0F, /* Byte count:   15 */

   /* Data bytes for block */
   0x20,  0x00,  0x20,  0x00,  0x05,  0x01,  0x13,  0x00,  
   0x10,  0x81,  0x05,  0x01,  0x51,  0x00,  0x10,  

   /* Check Byte: Inverse Synch */
   0x2A
};

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h file to its primary configuration data. */                
const an_apiPrimaryConfigInfo an_apiPrimaryConfigData[an_apiChipCount] =
{
   /* systemA */
   {
      an_systemA_PrimaryConfigInfo, /* data */
      264,                          /* length */
   },

   /* systemA_IC */
   {
      an_systemA_IC_PrimaryConfigInfo, /* data */
      264,                          /* length */
   },

   /* systemB */
   {
      an_systemB_PrimaryConfigInfo, /* data */
      183,                          /* length */
   },

   /* systemB_IC */
   {
      an_systemB_IC_PrimaryConfigInfo, /* data */
      177                           /* length */
   }
};

/* This is the constant synchronizing header byte. */               
const an_Byte an_apiSynchByte = 0xD5;  /* 11010101 */

/* apiReconfigInfo for systemA */
an_apiReconfigInfo an_systemA_ReconfigInfo =
{
   NULL,   /* data */
   0,      /* length */
   64,     /* capacity */
   0,      /* lastUpdateIndex */
   0       /* flags */
};

/* apiReconfigInfo for systemA_IC */
an_apiReconfigInfo an_systemA_IC_ReconfigInfo =
{
   NULL,   /* data */
   0,      /* length */
   64,     /* capacity */
   0,      /* lastUpdateIndex */
   0       /* flags */
};

/* apiReconfigInfo for systemB */
an_apiReconfigInfo an_systemB_ReconfigInfo =
{
   NULL,   /* data */
   0,      /* length */
   64,     /* capacity */
   0,      /* lastUpdateIndex */
   0       /* flags */
};

/* apiReconfigInfo for systemB_IC */
an_apiReconfigInfo an_systemB_IC_ReconfigInfo =
{
   NULL,   /* data */
   0,      /* length */
   64,     /* capacity */
   0,      /* lastUpdateIndex */
   0       /* flags */
};

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h fileto the apiReconfigInfo struct of that chip. */        
an_apiReconfigInfo* an_apiReconfigData[an_apiChipCount] =
{
   &an_systemA_ReconfigInfo,      /* systemA */
   &an_systemA_IC_ReconfigInfo,   /* systemA_IC */
   &an_systemB_ReconfigInfo,      /* systemB */
   &an_systemB_IC_ReconfigInfo    /* systemB_IC */
};

/* There is one of these buffers for each programmable chip. */     
an_Byte an_systemA_ReconfigBuffer[64] = {0};       /* systemA */
an_Byte an_systemA_IC_ReconfigBuffer[64] = {0};    /* systemA_IC */
an_Byte an_systemB_ReconfigBuffer[64] = {0};       /* systemB */
an_Byte an_systemB_IC_ReconfigBuffer[64] = {0};    /* systemB_IC */

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h file to the reconfiguration buffer of that chip. */       
an_Byte* an_apiReconfigBuffer[an_apiChipCount] =
{
   an_systemA_ReconfigBuffer,     /* systemA */
   an_systemA_IC_ReconfigBuffer,  /* systemA_IC */
   an_systemB_ReconfigBuffer,     /* systemB */
   an_systemB_IC_ReconfigBuffer   /* systemB_IC */
};

/* This array maps the numeric ID assigned to each CAM in the       
ApiCode.h file to the numeric ID of the chip which the CAM is in. */  
const an_Byte an_apiChipFromCAM[an_apiCAMCount] =
{
   an_systemA,          /* "an_systemA_GainHalf2" in chip "systemA" */
   an_systemA_IC,       /* "an_systemA_IC_GainHalf1" in chip "systemA_IC" */
   an_systemA_IC,       /* "an_systemA_IC_Multiplier1" in chip "systemA_IC" */
   an_systemA_IC,       /* "an_systemA_IC_Multiplier2" in chip "systemA_IC" */
   an_systemA_IC,       /* "an_systemA_IC_SumDiff1" in chip "systemA_IC" */
   an_systemA_IC,       /* "an_systemA_IC_SumDiff2" in chip "systemA_IC" */
   an_systemA,          /* "an_systemA_Multiplier3" in chip "systemA" */
   an_systemA,          /* "an_systemA_Multiplier4" in chip "systemA" */
   an_systemA,          /* "an_systemA_SumDiff3" in chip "systemA" */
   an_systemA,          /* "an_systemA_SumDiff4" in chip "systemA" */
   an_systemB_IC,       /* "an_systemB_IC_Integrator1" in chip "systemB_IC" */
   an_systemB_IC,       /* "an_systemB_IC_Integrator2" in chip "systemB_IC" */
   an_systemB_IC,       /* "an_systemB_IC_Integrator3" in chip "systemB_IC" */
   an_systemB_IC,       /* "an_systemB_IC_SumDiff1" in chip "systemB_IC" */
   an_systemB_IC,       /* "an_systemB_IC_SumDiff2" in chip "systemB_IC" */
   an_systemB_IC,       /* "an_systemB_IC_SumDiff3" in chip "systemB_IC" */
   an_systemB,          /* "an_systemB_Integrator4" in chip "systemB" */
   an_systemB,          /* "an_systemB_Integrator5" in chip "systemB" */
   an_systemB,          /* "an_systemB_Integrator6" in chip "systemB" */
   an_systemB,          /* "an_systemB_SumDiff4" in chip "systemB" */
   an_systemB,          /* "an_systemB_SumDiff5" in chip "systemB" */
   an_systemB           /* "an_systemB_SumDiff6" in chip "systemB" */
};

/* Component data table for the apiCapacitor's of GainHalf2. */
extern const an_apiCapacitor an_systemA_GainHalf2_Capacitor[2] = 
{
   /* Cin   */ { 0x09, 0x05, }, /* 9, 5 */
   /* Cout  */ { 0x09, 0x04  }  /* 9, 4 */
};

/* Component data table for the apiCapacitor's of GainHalf1. */
extern const an_apiCapacitor an_systemA_IC_GainHalf1_Capacitor[2] = 
{
   /* Cin   */ { 0x09, 0x05, }, /* 9, 5 */
   /* Cout  */ { 0x09, 0x04  }  /* 9, 4 */
};

/* Component data table for the apiCapacitor's of Multiplier1. */
extern const an_apiCapacitor an_systemA_IC_Multiplier1_Capacitor[2] = 
{
   /* Cin   */ { 0x03, 0x04, }, /* 3, 4 */
   /* Cout  */ { 0x03, 0x03  }  /* 3, 3 */
};

/* Component data table for the apiCapacitor's of Multiplier2. */
extern const an_apiCapacitor an_systemA_IC_Multiplier2_Capacitor[2] = 
{
   /* Cin   */ { 0x07, 0x03, }, /* 7, 3 */
   /* Cout  */ { 0x07, 0x02  }  /* 7, 2 */
};

/* Component data table for the apiCapacitor's of SumDiff1. */
extern const an_apiCapacitor an_systemA_IC_SumDiff1_Capacitor[3] = 
{
   /* CinA  */ { 0x03, 0x07, }, /* 3, 7 */
   /* CinB  */ { 0x03, 0x06, }, /* 3, 6 */
   /* Cout  */ { 0x03, 0x05  }  /* 3, 5 */
};

/* Component data table for the apiCapacitor's of SumDiff2. */
extern const an_apiCapacitor an_systemA_IC_SumDiff2_Capacitor[4] = 
{
   /* CinA  */ { 0x07, 0x07, }, /* 7, 7 */
   /* CinB  */ { 0x07, 0x06, }, /* 7, 6 */
   /* CinC  */ { 0x07, 0x05, }, /* 7, 5 */
   /* Cout  */ { 0x07, 0x04  }  /* 7, 4 */
};

/* Component data table for the apiCapacitor's of Multiplier3. */
extern const an_apiCapacitor an_systemA_Multiplier3_Capacitor[2] = 
{
   /* Cin   */ { 0x07, 0x03, }, /* 7, 3 */
   /* Cout  */ { 0x07, 0x02  }  /* 7, 2 */
};

/* Component data table for the apiCapacitor's of Multiplier4. */
extern const an_apiCapacitor an_systemA_Multiplier4_Capacitor[2] = 
{
   /* Cin   */ { 0x03, 0x04, }, /* 3, 4 */
   /* Cout  */ { 0x03, 0x03  }  /* 3, 3 */
};

/* Component data table for the apiCapacitor's of SumDiff3. */
extern const an_apiCapacitor an_systemA_SumDiff3_Capacitor[4] = 
{
   /* CinA  */ { 0x07, 0x07, }, /* 7, 7 */
   /* CinB  */ { 0x07, 0x06, }, /* 7, 6 */
   /* CinC  */ { 0x07, 0x05, }, /* 7, 5 */
   /* Cout  */ { 0x07, 0x04  }  /* 7, 4 */
};

/* Component data table for the apiCapacitor's of SumDiff4. */
extern const an_apiCapacitor an_systemA_SumDiff4_Capacitor[3] = 
{
   /* CinA  */ { 0x03, 0x07, }, /* 3, 7 */
   /* CinB  */ { 0x03, 0x06, }, /* 3, 6 */
   /* Cout  */ { 0x03, 0x05  }  /* 3, 5 */
};

/* Component data table for the apiCapacitor's of Integrator1. */
extern const an_apiCapacitor an_systemB_IC_Integrator1_Capacitor[2] = 
{
   /* Cin   */ { 0x03, 0x04, }, /* 3, 4 */
   /* Cint  */ { 0x03, 0x03  }  /* 3, 3 */
};

/* Component data table for the apiCapacitor's of Integrator2. */
extern const an_apiCapacitor an_systemB_IC_Integrator2_Capacitor[2] = 
{
   /* Cin   */ { 0x05, 0x04, }, /* 5, 4 */
   /* Cint  */ { 0x05, 0x03  }  /* 5, 3 */
};

/* Component data table for the apiCapacitor's of Integrator3. */
extern const an_apiCapacitor an_systemB_IC_Integrator3_Capacitor[2] = 
{
   /* Cin   */ { 0x09, 0x04, }, /* 9, 4 */
   /* Cint  */ { 0x09, 0x03  }  /* 9, 3 */
};

/* Component data table for the apiCapacitor's of SumDiff1. */
extern const an_apiCapacitor an_systemB_IC_SumDiff1_Capacitor[3] = 
{
   /* CinA  */ { 0x03, 0x07, }, /* 3, 7 */
   /* CinB  */ { 0x03, 0x06, }, /* 3, 6 */
   /* Cout  */ { 0x03, 0x05  }  /* 3, 5 */
};

/* Component data table for the apiCapacitor's of SumDiff2. */
extern const an_apiCapacitor an_systemB_IC_SumDiff2_Capacitor[3] = 
{
   /* CinA  */ { 0x05, 0x07, }, /* 5, 7 */
   /* CinB  */ { 0x05, 0x06, }, /* 5, 6 */
   /* Cout  */ { 0x05, 0x05  }  /* 5, 5 */
};

/* Component data table for the apiCapacitor's of SumDiff3. */
extern const an_apiCapacitor an_systemB_IC_SumDiff3_Capacitor[3] = 
{
   /* CinA  */ { 0x09, 0x07, }, /* 9, 7 */
   /* CinB  */ { 0x09, 0x06, }, /* 9, 6 */
   /* Cout  */ { 0x09, 0x05  }  /* 9, 5 */
};

/* Component data table for the apiCapacitor's of Integrator4. */
extern const an_apiCapacitor an_systemB_Integrator4_Capacitor[2] = 
{
   /* Cin   */ { 0x09, 0x04, }, /* 9, 4 */
   /* Cint  */ { 0x09, 0x03  }  /* 9, 3 */
};

/* Component data table for the apiCapacitor's of Integrator5. */
extern const an_apiCapacitor an_systemB_Integrator5_Capacitor[2] = 
{
   /* Cin   */ { 0x05, 0x04, }, /* 5, 4 */
   /* Cint  */ { 0x05, 0x03  }  /* 5, 3 */
};

/* Component data table for the apiCapacitor's of Integrator6. */
extern const an_apiCapacitor an_systemB_Integrator6_Capacitor[2] = 
{
   /* Cin   */ { 0x03, 0x04, }, /* 3, 4 */
   /* Cint  */ { 0x03, 0x03  }  /* 3, 3 */
};

/* Component data table for the apiCapacitor's of SumDiff4. */
extern const an_apiCapacitor an_systemB_SumDiff4_Capacitor[3] = 
{
   /* CinA  */ { 0x09, 0x07, }, /* 9, 7 */
   /* CinB  */ { 0x09, 0x06, }, /* 9, 6 */
   /* Cout  */ { 0x09, 0x05  }  /* 9, 5 */
};

/* Component data table for the apiCapacitor's of SumDiff5. */
extern const an_apiCapacitor an_systemB_SumDiff5_Capacitor[3] = 
{
   /* CinA  */ { 0x05, 0x07, }, /* 5, 7 */
   /* CinB  */ { 0x05, 0x06, }, /* 5, 6 */
   /* Cout  */ { 0x05, 0x05  }  /* 5, 5 */
};

/* Component data table for the apiCapacitor's of SumDiff6. */
extern const an_apiCapacitor an_systemB_SumDiff6_Capacitor[3] = 
{
   /* CinA  */ { 0x03, 0x07, }, /* 3, 7 */
   /* CinB  */ { 0x03, 0x06, }, /* 3, 6 */
   /* Cout  */ { 0x03, 0x05  }  /* 3, 5 */
};

/* Component map for GainHalf2 */
void* an_systemA_GainHalf2_Components[2] = 
{
   (void*) &an_systemA_GainHalf2_Capacitor[0],  /* Cin */
   (void*) &an_systemA_GainHalf2_Capacitor[1]  /* Cout */
};

/* Component map for GainHalf1 */
void* an_systemA_IC_GainHalf1_Components[2] = 
{
   (void*) &an_systemA_IC_GainHalf1_Capacitor[0],  /* Cin */
   (void*) &an_systemA_IC_GainHalf1_Capacitor[1]  /* Cout */
};

/* Component map for Multiplier1 */
void* an_systemA_IC_Multiplier1_Components[2] = 
{
   (void*) &an_systemA_IC_Multiplier1_Capacitor[0],  /* Cin */
   (void*) &an_systemA_IC_Multiplier1_Capacitor[1]  /* Cout */
};

/* Component map for Multiplier2 */
void* an_systemA_IC_Multiplier2_Components[2] = 
{
   (void*) &an_systemA_IC_Multiplier2_Capacitor[0],  /* Cin */
   (void*) &an_systemA_IC_Multiplier2_Capacitor[1]  /* Cout */
};

/* Component map for SumDiff1 */
void* an_systemA_IC_SumDiff1_Components[4] = 
{
   (void*) &an_systemA_IC_SumDiff1_Capacitor[0],  /* CinA */
   (void*) &an_systemA_IC_SumDiff1_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemA_IC_SumDiff1_Capacitor[2]  /* Cout */
};

/* Component map for SumDiff2 */
void* an_systemA_IC_SumDiff2_Components[4] = 
{
   (void*) &an_systemA_IC_SumDiff2_Capacitor[0],  /* CinA */
   (void*) &an_systemA_IC_SumDiff2_Capacitor[1],  /* CinB */
   (void*) &an_systemA_IC_SumDiff2_Capacitor[2],  /* CinC */
   (void*) &an_systemA_IC_SumDiff2_Capacitor[3]  /* Cout */
};

/* Component map for Multiplier3 */
void* an_systemA_Multiplier3_Components[2] = 
{
   (void*) &an_systemA_Multiplier3_Capacitor[0],  /* Cin */
   (void*) &an_systemA_Multiplier3_Capacitor[1]  /* Cout */
};

/* Component map for Multiplier4 */
void* an_systemA_Multiplier4_Components[2] = 
{
   (void*) &an_systemA_Multiplier4_Capacitor[0],  /* Cin */
   (void*) &an_systemA_Multiplier4_Capacitor[1]  /* Cout */
};

/* Component map for SumDiff3 */
void* an_systemA_SumDiff3_Components[4] = 
{
   (void*) &an_systemA_SumDiff3_Capacitor[0],  /* CinA */
   (void*) &an_systemA_SumDiff3_Capacitor[1],  /* CinB */
   (void*) &an_systemA_SumDiff3_Capacitor[2],  /* CinC */
   (void*) &an_systemA_SumDiff3_Capacitor[3]  /* Cout */
};

/* Component map for SumDiff4 */
void* an_systemA_SumDiff4_Components[4] = 
{
   (void*) &an_systemA_SumDiff4_Capacitor[0],  /* CinA */
   (void*) &an_systemA_SumDiff4_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemA_SumDiff4_Capacitor[2]  /* Cout */
};

/* Component map for Integrator1 */
void* an_systemB_IC_Integrator1_Components[2] = 
{
   (void*) &an_systemB_IC_Integrator1_Capacitor[0],  /* Cin */
   (void*) &an_systemB_IC_Integrator1_Capacitor[1]  /* Cint */
};

/* Component map for Integrator2 */
void* an_systemB_IC_Integrator2_Components[2] = 
{
   (void*) &an_systemB_IC_Integrator2_Capacitor[0],  /* Cin */
   (void*) &an_systemB_IC_Integrator2_Capacitor[1]  /* Cint */
};

/* Component map for Integrator3 */
void* an_systemB_IC_Integrator3_Components[2] = 
{
   (void*) &an_systemB_IC_Integrator3_Capacitor[0],  /* Cin */
   (void*) &an_systemB_IC_Integrator3_Capacitor[1]  /* Cint */
};

/* Component map for SumDiff1 */
void* an_systemB_IC_SumDiff1_Components[4] = 
{
   (void*) &an_systemB_IC_SumDiff1_Capacitor[0],  /* CinA */
   (void*) &an_systemB_IC_SumDiff1_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_IC_SumDiff1_Capacitor[2]  /* Cout */
};

/* Component map for SumDiff2 */
void* an_systemB_IC_SumDiff2_Components[4] = 
{
   (void*) &an_systemB_IC_SumDiff2_Capacitor[0],  /* CinA */
   (void*) &an_systemB_IC_SumDiff2_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_IC_SumDiff2_Capacitor[2]  /* Cout */
};

/* Component map for SumDiff3 */
void* an_systemB_IC_SumDiff3_Components[4] = 
{
   (void*) &an_systemB_IC_SumDiff3_Capacitor[0],  /* CinA */
   (void*) &an_systemB_IC_SumDiff3_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_IC_SumDiff3_Capacitor[2]  /* Cout */
};

/* Component map for Integrator4 */
void* an_systemB_Integrator4_Components[2] = 
{
   (void*) &an_systemB_Integrator4_Capacitor[0],  /* Cin */
   (void*) &an_systemB_Integrator4_Capacitor[1]  /* Cint */
};

/* Component map for Integrator5 */
void* an_systemB_Integrator5_Components[2] = 
{
   (void*) &an_systemB_Integrator5_Capacitor[0],  /* Cin */
   (void*) &an_systemB_Integrator5_Capacitor[1]  /* Cint */
};

/* Component map for Integrator6 */
void* an_systemB_Integrator6_Components[2] = 
{
   (void*) &an_systemB_Integrator6_Capacitor[0],  /* Cin */
   (void*) &an_systemB_Integrator6_Capacitor[1]  /* Cint */
};

/* Component map for SumDiff4 */
void* an_systemB_SumDiff4_Components[4] = 
{
   (void*) &an_systemB_SumDiff4_Capacitor[0],  /* CinA */
   (void*) &an_systemB_SumDiff4_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_SumDiff4_Capacitor[2]  /* Cout */
};

/* Component map for SumDiff5 */
void* an_systemB_SumDiff5_Components[4] = 
{
   (void*) &an_systemB_SumDiff5_Capacitor[0],  /* CinA */
   (void*) &an_systemB_SumDiff5_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_SumDiff5_Capacitor[2]  /* Cout */
};

/* Component map for SumDiff6 */
void* an_systemB_SumDiff6_Components[4] = 
{
   (void*) &an_systemB_SumDiff6_Capacitor[0],  /* CinA */
   (void*) &an_systemB_SumDiff6_Capacitor[1],  /* CinB */
   (void*) an_apiInvalid,                 /* CinC */
   (void*) &an_systemB_SumDiff6_Capacitor[2]  /* Cout */
};

/* This array maps the numeric ID assigned to each CAM in the       
ApiCode.h file to its component map */                              
void** an_apiCAMComponentData[an_apiCAMCount] =
{
   an_systemA_GainHalf2_Components,         /* an_systemA_GainHalf2 */
   an_systemA_IC_GainHalf1_Components,      /* an_systemA_IC_GainHalf1 */
   an_systemA_IC_Multiplier1_Components,    /* an_systemA_IC_Multiplier1 */
   an_systemA_IC_Multiplier2_Components,    /* an_systemA_IC_Multiplier2 */
   an_systemA_IC_SumDiff1_Components,       /* an_systemA_IC_SumDiff1 */
   an_systemA_IC_SumDiff2_Components,       /* an_systemA_IC_SumDiff2 */
   an_systemA_Multiplier3_Components,       /* an_systemA_Multiplier3 */
   an_systemA_Multiplier4_Components,       /* an_systemA_Multiplier4 */
   an_systemA_SumDiff3_Components,          /* an_systemA_SumDiff3 */
   an_systemA_SumDiff4_Components,          /* an_systemA_SumDiff4 */
   an_systemB_IC_Integrator1_Components,    /* an_systemB_IC_Integrator1 */
   an_systemB_IC_Integrator2_Components,    /* an_systemB_IC_Integrator2 */
   an_systemB_IC_Integrator3_Components,    /* an_systemB_IC_Integrator3 */
   an_systemB_IC_SumDiff1_Components,       /* an_systemB_IC_SumDiff1 */
   an_systemB_IC_SumDiff2_Components,       /* an_systemB_IC_SumDiff2 */
   an_systemB_IC_SumDiff3_Components,       /* an_systemB_IC_SumDiff3 */
   an_systemB_Integrator4_Components,       /* an_systemB_Integrator4 */
   an_systemB_Integrator5_Components,       /* an_systemB_Integrator5 */
   an_systemB_Integrator6_Components,       /* an_systemB_Integrator6 */
   an_systemB_SumDiff4_Components,          /* an_systemB_SumDiff4 */
   an_systemB_SumDiff5_Components,          /* an_systemB_SumDiff5 */
   an_systemB_SumDiff6_Components           /* an_systemB_SumDiff6 */
};

/* Table to map clock divider ID's to the divider's current value for  
chip systemB */                                                     
short an_systemB_Clocks[12] =
{
   0,      /* ApexClock5DelayPeriods */
   1,      /* ApexClock5 */
   0,      /* ApexClock4DelayPeriods */
   1,      /* ApexClock4 */
   64,     /* ApexClock3 */
   16,     /* ApexClock2 */
   1,      /* ApexClock1 */
   4,      /* ApexClock0 */
   0,      /* ClockPowerUps DO NOT USE*/
   1,      /* Sys1Divisor */
   1,      /* Sys2Divisor */
   250     /* Sys1/Sys2 flags - true implies Sys1 */
};

/* Table to map clock divider ID's to the divider's current value for  
chip systemB_IC */                                                  
short an_systemB_IC_Clocks[12] =
{
   0,      /* ApexClock5DelayPeriods */
   1,      /* ApexClock5 */
   0,      /* ApexClock4DelayPeriods */
   1,      /* ApexClock4 */
   64,     /* ApexClock3 */
   16,     /* ApexClock2 */
   1,      /* ApexClock1 */
   4,      /* ApexClock0 */
   0,      /* ClockPowerUps DO NOT USE*/
   1,      /* Sys1Divisor */
   1,      /* Sys2Divisor */
   250     /* Sys1/Sys2 flags - true implies Sys1 */
};

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h file to the chip's clock data. */                         
short* an_apiClockDivisorData[an_apiChipCount] =
{
   (short*) an_apiInvalid,
   (short*) an_apiInvalid,
   an_systemB_Clocks,
   an_systemB_IC_Clocks
};

/* This array maps the numeric ID assigned to each chip in the      
ApiCode.h file to the chip's master clock frequency. */             
const long an_apiMasterClockData[an_apiChipCount] =
{
   (long) 0.0,
   (long) 0.0,
   (long) 4000000.000000,
   (long) 4000000.000000
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator1 */                                                      
const an_ApexClockDivisor an_systemB_IC_Integrator1_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator2 */                                                      
const an_ApexClockDivisor an_systemB_IC_Integrator2_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator3 */                                                      
const an_ApexClockDivisor an_systemB_IC_Integrator3_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator4 */                                                      
const an_ApexClockDivisor an_systemB_Integrator4_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator5 */                                                      
const an_ApexClockDivisor an_systemB_Integrator5_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* Table to map module virtual clocks to actual chip clock for module  
Integrator6 */                                                      
const an_ApexClockDivisor an_systemB_Integrator6_CAMClocks[4] =
{
   an_ApexClockDivisor_Clock2,           /* ClockA */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockB */
   (an_ApexClockDivisor) an_apiInvalid,  /* ClockC */
   (an_ApexClockDivisor) an_apiInvalid   /* ClockD */
};

/* This array maps the numeric ID assigned to each CAM in the       
ApiCode.h file to the CAM's virtual clock mapping. */               
const an_ApexClockDivisor* an_apiCAMClockToApexChipClock[an_apiCAMCount] =
{
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   an_systemB_IC_Integrator1_CAMClocks,
   an_systemB_IC_Integrator2_CAMClocks,
   an_systemB_IC_Integrator3_CAMClocks,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   an_systemB_Integrator4_CAMClocks,
   an_systemB_Integrator5_CAMClocks,
   an_systemB_Integrator6_CAMClocks,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid,
   (an_ApexClockDivisor*) an_apiInvalid
};

/*##################################################################*\
#                                                                    #
#                             Functions                              #
#                                                                    #
\*##################################################################*/

/********************************************************************\
 *                      Primary Configuration                       * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                      GetPrimaryConfigData                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves the primary configuration data for the chip. The    |
  |  returned data begins with the synch byte and ends with the    |
  |  last error byte. There are no pad bytes included. The number  |
  |  of bytes in the configuration data is set in count.           |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetPrimaryConfigData(an_Chip chip, int* count)
     {
        /* Set how long it is */
        *count = an_apiPrimaryConfigData[chip].length;
        
        /* Return the pointer to the configuration data */
        return an_apiPrimaryConfigData[chip].data;
     }

  /*--------------------------------------------------------------*\
  |                          GetResetData                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves configuration data that will perform a soft reset   |
  |  on the chip. The returned data begins with the synch byte and |
  |  ends with the control byte. There are no pad bytes included.  |
  |  The number of bytes in the configuration data is set in       |
  |  count.                                                        |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetResetData(an_Chip chip, int* count)
     {
        /* Initialize our data template */
        static an_Byte resetData[] =
        {
           0xD5, /* Synch                 */
           0x00, /* Address1 Placeholder  */
           0x6F  /* Control Byte (48 Vortex | 27 Apex) */
        };
        
        /* Set it to use this chip's Address1 */
        resetData[1] = an_apiAddress1[chip];
        
        /* Set how long it is */
        *count = sizeof(resetData);
        
        /* Return the pointer to the data */
        return resetData;
     }

/********************************************************************\
 *                         Power Management                         * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                       GetVortexSleepData                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves configuration data that will put the chip to sleep. |
  |  If powerDown is non-zero, then all analog functions will be   |
  |  turned off except the crystal oscillator. The returned data   |
  |  begins with the synch byte and ends with the last error byte. |
  |  There are no pad bytes included. The number of bytes in the   |
  |  configuration data is set in count.                           |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetVortexSleepData(an_Chip chip, int* count, an_Bool powerDown)
     {
        /* Initialize our data template */
        static an_Byte sleepData[] =
        {
           0xD5,                            /* Synch                 */
           0x00,                            /* Address1 Placeholder  */
           an_VortexControlByte_EndExecute,   /* Control Byte          */
        
           /* Address: Byte 14, Bank 1 */
           /* The Byte value is required to have bit 7 set...) */
           0x8E,
           0x01,
        
           /* Data count and data byte place holder */
           0x01,
           0x00,
        
           /* Synch */
           0x2A
        };
        
        /* Set the proper power-up bit */
        sleepData[6] = powerDown ? 0x0 : 0x1;
        
        /* Set it to use this chip's Address1*/
        sleepData[1] = an_apiAddress1[chip];
        
        /* Set how long it is */
        *count = sizeof(sleepData);
        
        /* Return the pointer to the data */
        return sleepData;
     }

  /*--------------------------------------------------------------*\
  |                        GetApexSleepData                        |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves configuration data that will put the chip to sleep. |
  |  If powerDown is non-zero, then the analog cells are powered   |
  |  DOWN. If VMR is non-zero, then VMR is powered UP. If watchDog |
  |  is non-zero, then the watchDog circuit is powered up. The     |
  |  returned data begins with the synch byte and ends with the    |
  |  last error byte. There are no pad bytes included. The number  |
  |  of bytes in the configuration data is set in count.           |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetApexSleepData(an_Chip chip, int* count, 
                                       an_Bool powerDown,
                                       an_Bool VMR,
                                       an_Bool watchDog
                                       )
     {
        /* Initialize our data template */
        static an_Byte sleepData[] =
        {
           0xD5,                            /* Synch                 */
           0x00,                            /* Address1 Placeholder  */
           an_ApexControlByte_EndExecute,     /* Control Byte          */
        
           /* Address: Byte 17 (0x11), Bank 0 */
           0x91,
           0x00,
        
           /* Data count and data byte place holder */
           0x01,
           0x00,
        
           /* Synch */
           0x2A
        };
        
        /* Set the proper power-up bits */
        sleepData[6] = 0x80;                      /* Everything powered down value */
        if(!powerDown) sleepData[6]   += 0x01;    /* set analog cells power up bit */
        if(VMR) sleepData[6]          += 0x70;    /* set VMR bits power up         */
        if(watchDog) sleepData[6]     += 0x02;    /* set watchDog enable bit       */
        
        /* Set it to use this chip's Address1*/
        sleepData[1] = an_apiAddress1[chip];
        
        /* Set how long it is */
        *count = sizeof(sleepData);
        
        /* Return the pointer to the data */
        return sleepData;
     }

/********************************************************************\
 *                         Reconfiguration                          * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                  InitializeVortexReconfigData                  |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Configures memory for the reconfiguration data and does       |
  |  initial setup of the header. Must be called prior to using    |
  |  any other reconfiguration functions for the chip.             |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_InitializeVortexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Initialize the pointer to the buffer */
        pInfo->data = an_apiReconfigBuffer[chip];
        
        /* Now do everything that needs to be done in a reset situation */
        an_ClearVortexReconfigData(chip);
     }

  /*--------------------------------------------------------------*\
  |                   InitializeApexReconfigData                   |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Configures memory for the reconfiguration data and does       |
  |  initial setup of the header. Must be called prior to using    |
  |  any other reconfiguration functions for the chip.             |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_InitializeApexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Initialize the pointer to the buffer */
        pInfo->data = an_apiReconfigBuffer[chip];
        
        /* Now do everything that needs to be done in a reset situation */
        an_ClearApexReconfigData(chip);
     }

  /*--------------------------------------------------------------*\
  |                    ClearVortexReconfigData                     |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Resets the reconfiguration data for the chip back to what it  |
  |  was when ApiCall:InitializeVortexReconfigData was first       |
  |  called. This does not free any memory.                        |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_ClearVortexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* We don't have to remove any data, just adjust the info */
        an_apiReconfigData[chip]->length = 3;
        an_apiReconfigData[chip]->lastUpdateIndex = 0;
        
        /* Reset the stream info flags */
        pInfo->flags = an_ApiReconfigState_Initialized;
        
        /* Configure the data header for a reconfiguration */
        pInfo->data[0] = an_apiSynchByte;       /* Synch Byte   */
        pInfo->data[1] = an_apiAddress1[chip];  /* Address1    */
        pInfo->data[2] = an_VortexControlByte_EndExecute;     /* Control Byte */
     }

  /*--------------------------------------------------------------*\
  |                     ClearApexReconfigData                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Resets the reconfiguration data for the chip back to what it  |
  |  was when ApiCall:InitializeApexReconfigData was first called. |
  |  This does not free any memory.                                |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_ClearApexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* We don't have to remove any data, just adjust the info */
        an_apiReconfigData[chip]->length = 3;
        an_apiReconfigData[chip]->lastUpdateIndex = 0;
        
        /* Reset the stream info flags */
        pInfo->flags = an_ApiReconfigState_Initialized;
        
        /* Configure the data header for a reconfiguration */
        pInfo->data[0] = an_apiSynchByte;       /* Synch Byte   */
        pInfo->data[1] = an_apiAddress1[chip];  /* Address1    */
        pInfo->data[2] = an_ApexControlByte_EndExecute;     /* Control Byte */
     }

  /*--------------------------------------------------------------*\
  |                   ShutdownVortexReconfigData                   |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Frees memory allocated by an_InitializeVortexReconfigData.    |
  |  an_InitializeVortexReconfigData must be called again prior to |
  |  using any other reconfiguration functions for the chip.       |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_ShutdownVortexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Update the stream info */
        pInfo->data = NULL;
        pInfo->length = 0;
        pInfo->flags  = 0;
     }

  /*--------------------------------------------------------------*\
  |                    ShutdownApexReconfigData                    |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Frees memory allocated by an_InitializeApexReconfigData.      |
  |  an_InitializeApexReconfigData must be called again prior to   |
  |  using any other reconfiguration functions for the chip.       |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_ShutdownApexReconfigData(an_Chip chip)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Update the stream info */
        pInfo->data = NULL;
        pInfo->length = 0;
        pInfo->flags  = 0;
     }

  /*--------------------------------------------------------------*\
  |                     GetVortexReconfigData                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves the current reconfiguration data for the chip. The  |
  |  returned data begins with the synch byte and ends with the    |
  |  last error byte. There are no pad bytes included. The number  |
  |  of bytes in the reconfiguration is set in count. The data     |
  |  returned from this function is invalidated if another         |
  |  reconfiguration function is called for this chip. The data    |
  |  returned from this function should not be modified.           |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetVortexReconfigData(an_Chip chip, int* count)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Set how big it is. If it is 3, then there is no real data. */
        *count = (pInfo->length == 3) ? 0 : pInfo->length;
        
        /* Return the pointer to the data */
        return pInfo->data;
     }

  /*--------------------------------------------------------------*\
  |                      GetApexReconfigData                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves the current reconfiguration data for the chip. The  |
  |  returned data begins with the synch byte and ends with the    |
  |  last error byte. There are no pad bytes included. The number  |
  |  of bytes in the reconfiguration is set in count. The data     |
  |  returned from this function is invalidated if another         |
  |  reconfiguration function is called for this chip. The data    |
  |  returned from this function should not be modified.           |
  |                                                                |
  \*--------------------------------------------------------------*/

     const an_Byte* an_GetApexReconfigData(an_Chip chip, int* count)
     {
        /* Get a pointer to the info struct */
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Set how big it is. If it is 3, then there is no real data. */
        *count = (pInfo->length == 3) ? 0 : pInfo->length;
        
        /* Return the pointer to the data */
        return pInfo->data;
     }

  /*--------------------------------------------------------------*\
  |                 SetVortexReconfigControlFlags                  |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Sets flags in the control byte of the reconfiguration data    |
  |  for a Vortex chip.                                            |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetVortexReconfigControlFlags(an_Chip chip, an_VortexControlByte flags)
     {
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Control byte is index 2 */
        pInfo->data[2] = flags;
     }

  /*--------------------------------------------------------------*\
  |                  SetApexReconfigControlFlags                   |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Sets flags in the control byte of the reconfiguration data    |
  |  for an Apex chip.                                             |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetApexReconfigControlFlags(an_Chip chip, an_ApexControlByte flags)
     {
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Control byte is index 2 */
        pInfo->data[2] = flags;
     }

  /*--------------------------------------------------------------*\
  |                 SetApexReconfigControlFlagsNOP                 |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Sets flags in the control byte of the reconfiguration data    |
  |  for an Apex chip.                                             |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetApexReconfigControlFlagsNOP(an_Chip chip, an_ApexControlByte flags)
     {
        
     }

  /*--------------------------------------------------------------*\
  |                 GetVortexReconfigControlFlags                  |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves the flags in the control byte of the                |
  |  reconfiguration data for the chip.                            |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_VortexControlByte an_GetVortexReconfigControlFlags(an_Chip chip)
     {
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Control byte is index 2 */
        return pInfo->data[2];
     }

  /*--------------------------------------------------------------*\
  |                  GetApexReconfigControlFlags                   |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Retrieves the flags in the control byte of the                |
  |  reconfiguration data for the chip.                            |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_ApexControlByte an_GetApexReconfigControlFlags(an_Chip chip)
     {
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        
        /* Control byte is index 2 */
        return pInfo->data[2];
     }

/********************************************************************\
 *                          CAM Functions                           * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                     GetApexClockFrequency                      |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Returns the frequency in hz for the CAM clock desired. The    |
  |  clock values are taken from the chip the CAM is in. This      |
  |  should only be called from within CAM functions, and is not   |
  |  intended for use otherwise.                                   |
  |                                                                |
  \*--------------------------------------------------------------*/

     //NEED TO TAKE WHICH PRESCALER WAS USED INTO ACCOUNT, i.e., an_ClockDivisor_PreScale
an_Frequency an_GetApexClockFrequency(an_CAM cam, an_CAMClock camClock)
     {
        an_Chip chip = an_apiChipFromCAM[cam];
        int sysClockScale;
        int chipClockNumber = an_apiCAMClockToApexChipClock[cam][camClock];
         
        //Sys1 == true;  Sys2 == false.
        if(an_apiClockDivisorData[chip][an_ApexClockDivisor_ClockSys1Sys2Flag] & (1<<chipClockNumber)){
           //Using Sys1
           sysClockScale = an_apiClockDivisorData[chip][an_ApexClockDivisor_ClockSys1];
        }else{
           //Using Sys2
           sysClockScale = an_apiClockDivisorData[chip][an_ApexClockDivisor_ClockSys2];
        }
        
        return an_apiMasterClockData[chip] / 
           (sysClockScale * an_apiClockDivisorData[chip][chipClockNumber]);
     }

  /*--------------------------------------------------------------*\
  |                          SetCapValue                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Set a capacitor to a given value. The new 8-bit value is      |
  |  value. capID is the name given to represent the capacitor in  |
  |  the CAM net list. This should only be called from within CAM  |
  |  functions, and is not intended for use otherwise.             |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_SetCapValue(an_CAM cam, an_Component capID, an_Byte value)
     {
        /* First figure out what cap this is for */
        const an_apiCapacitor* pCap = an_apiCAMComponentData[cam][capID];
        
        /* And then just do a regular one-byte update */
        an_BuildReconfigDataBlock(an_apiChipFromCAM[cam], pCap->bank, pCap->byteNum, &value, 1);
     }

  /*--------------------------------------------------------------*\
  |                         ChooseCapRatio                         |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Given a desired gain, this function will calculate the ideal  |
  |  capacitor values. The realized capacitor values will be       |
  |  returned in the pointers that are passed in.                  |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_ChooseCapRatio(double dGain, an_Byte* pCap1, an_Byte* pCap2)
     {
        double realizedGain;
        double realizedError;
        double currentError = 99999;
        
        an_Byte capTry1;
        an_Byte capTry2;
        
        /* Start off with some default values */
        an_Byte currentCap1 = 1;
        an_Byte currentCap2 = 1;
        
        /* Run all the way down the scale looking for the best ratio... */
        for (capTry2 = 255; capTry2 > 0; capTry2--)
        {
           capTry1 = an_AdjustCap(dGain * capTry2);
        
           /* See how good it came out */
           realizedGain  = (double) capTry1 / (double) capTry2;
           realizedError = fabs( ( dGain - realizedGain) / dGain);
        
           /* If its the best so far, then store the results */
           if( realizedError < currentError ) 
           { 
              currentError = realizedError;
        
              currentCap1 = capTry1;
              currentCap2 = capTry2;
           }
        }
        
        *pCap1 = currentCap1;
        *pCap2 = currentCap2;
     }

  /*--------------------------------------------------------------*\
  |                           AdjustCap                            |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Returns the 8-bit capacitor value most closely representing   |
  |  the passed in value.                                          |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Byte an_AdjustCap(double dValue)
     {
        /* Start by just rounding.  We will handle special cases later */
        an_Byte capValue = (an_Byte) (dValue + 0.5);
        
        /* Constrain to 1 - 255 */
        if (dValue < 1.0)
        {
          capValue = 1;
        }
        else if (dValue > 255.0)
        {
          capValue = 255;
        }
         
        return capValue;
     }

  /*--------------------------------------------------------------*\
  |                      FixedChooseCapRatio                       |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Given a desired gain, this function will calculate the ideal  |
  |  capacitor values. The realized capacitor values will be       |
  |  returned in the pointers that are passed in.                  |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_FixedChooseCapRatio(double dGain, an_Byte* pCap1, an_Byte* pCap2)
     {
         an_Fixed realizedGain;
        an_Fixed workGain = an_FloatToFixed(dGain);
        an_Fixed realizedError;
        an_Fixed currentError = 0x7FFFFFFF;
         
        an_Byte capTry1;
        an_Byte capTry2;
        
        /* Start off with some default values */
        an_Byte currentCap1 = 1;
        an_Byte currentCap2 = 1;
        
        /* Run all the way down the scale looking for the best ratio... */
        for (capTry2 = 255; capTry2 > 0; capTry2--)
        {
           capTry1 = an_FixedAdjustCap(workGain * capTry2);
        
           /* See how good it came out */
           realizedGain = an_FixedDivide(an_IntToFixed(capTry1), an_IntToFixed(capTry2));
           realizedError = an_FixedDivide(an_FixedAbs(workGain - realizedGain), workGain);
        
           /* If it's the best so far, then store the results */
           if (realizedError < currentError)
           {
              currentError = realizedError;
        
              currentCap1 = capTry1;
              currentCap2 = capTry2;
           }
        }
        
        *pCap1 = currentCap1;
        *pCap2 = currentCap2;
     }

  /*--------------------------------------------------------------*\
  |                         FixedAdjustCap                         |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Returns the 8-bit capacitor value most closely representing   |
  |  the passed in value.                                          |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Byte an_FixedAdjustCap(an_Fixed fValue)
     {
        an_Byte capValue = (an_Byte) an_FixedToInt(fValue);
        
        if (fValue < 0x00010000)
        {
           capValue = 1;
        }
        else if (fValue > 0x00FF0000)
        {
           capValue = 255;
        }
        
        return capValue;
     }

/********************************************************************\
 *                         Fixed-Point Math                         * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                          FloatToFixed                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Convert from float to ApiName::fixed                          |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Fixed an_FloatToFixed(float fValue)
     {
        return (an_Fixed) (fValue * 65536.0);
     }

  /*--------------------------------------------------------------*\
  |                           IntToFixed                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Convert from int to ApiName::fixed                            |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Fixed an_IntToFixed(int value)
     {
        return ((an_Fixed) (value)) << 16;
     }

  /*--------------------------------------------------------------*\
  |                           FixedToInt                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Convert from ApiName::fixed to int                            |
  |                                                                |
  \*--------------------------------------------------------------*/

     int an_FixedToInt(an_Fixed fValue)
     {
        return (int) ((fValue + 0x8000) >> 16);
     }

  /*--------------------------------------------------------------*\
  |                          FixedToFloat                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Convert from ApiName::fixed to float                          |
  |                                                                |
  \*--------------------------------------------------------------*/

     float an_FixedToFloat(an_Fixed fValue)
     {
        //return (float) ((fValue + 0x8000) / 65536.0);
        return (float) (fValue / 65536.0);
     }

  /*--------------------------------------------------------------*\
  |                            FixedAbs                            |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function returns the absolute value of a fixed-point     |
  |  number.                                                       |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Fixed an_FixedAbs(an_Fixed fValue)
     {
        /* Sign is indicated by the MSB of the value. If set, number is negative. */
        if ((fValue & 0x80000000) != 0)
        {
           return -fValue;
        }
        else
        {
           return fValue;
        }
     }

  /*--------------------------------------------------------------*\
  |                         FixedMultiply                          |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function returns the result of multiplying two           |
  |  fixed-point numbers. Input fLeft is the left-side of the      |
  |  implied multiplication sign. It is the first value to         |
  |  multiply. Input fRight is the right-side of the implied       |
  |  multiplication sign. It is the second value to multiply. The  |
  |  return is the fixed-point result of the multiply. The         |
  |  fixed-point numbers are assumed to be in 16:16 form, although |
  |  the routine might work for any other fixed-point setup, as    |
  |  long as the two multiplicants are identical in their          |
  |  fixed-point setup. But this has not been tested.              |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Fixed an_FixedMultiply(an_Fixed fLeft, an_Fixed fRight)
     {
        unsigned short left_l, left_r, right_l, right_r;
        unsigned long left_r_right_r, left_r_right_l, left_l_right_r, left_l_right_l;
        
        an_Fixed result = 0;
        
        unsigned int left_neg = (fLeft & 0x80000000) != 0;
        unsigned int right_neg = (fRight & 0x80000000) != 0;
        
        /* In order to assure correct values, we're going to make all numbers positive, and
         * take care of the sign at the end. */
        if (left_neg) fLeft = -fLeft;
        if (right_neg) fRight = -fRight;
        
        /* Like elementary math, we're going to do this one word at a time. For example, 
         * we'll calculate the result of 660.33777 by 20.6752929, which is 13652.67680768.
         * In fixed-point notation, this is equivalent to multiplying 0x12345678 by 0x0140ACE0. So:
         * 				0294 5678   (fLeft)
         * 			*	0014 ACE0   (fRight)
         * 				---------
         * 				3A64 4900   (left_r * right_r = left_r_right_r)
         * 		 01BD B180			(left_l * right_r = left_l_right_r)
         * 		 0006 C160			(left_r * right_l = left_r_right_l)
         *   0000 3390					(left_l * right_l = Left_l_right_l)
         *   -------------------
         *   0000 3554 AD44 4900 
         *
         * Since this result in is 32:32 notation, we chop off the upper word and lower word
         * to give us the correct final result: 3554 AD44 = 13652.67681885, which is fairly
         * close to our floating-point result.
         *
         * Note that there are limitations to what can be done here. For example, the largest
         * number that can be represented in fixed-point 16:16 notation is 32767.99998474
         * (0x7FFFFFFF), therefore any result that might go over that amount will yield an
         * invalid result. No check is made to ensure that the result will be correct even
         * if the result overflows. No error is generated either.
         */
         
        left_l = (unsigned short)(fLeft >> 16);
        left_r = (unsigned short)(fLeft & 0xFFFF);
        
        right_l = (unsigned short)(fRight >> 16);
        right_r = (unsigned short)(fRight & 0xFFFF);
        
        left_r_right_r = (unsigned long)left_r * (unsigned long)right_r;
        left_r_right_l = (unsigned long)left_r * (unsigned long)right_l;
        left_l_right_r = (unsigned long)left_l * (unsigned long)right_r;
        left_l_right_l = (unsigned long)left_l * (unsigned long)right_l;
        
        /* Combine our individual lines to get the result */
        result = (left_r_right_r >> 16) +
                 (left_r_right_l) +
                 (left_l_right_r) +
                 (left_l_right_l << 16);
        
        /* If the left or the right (but not both) were negative, negate the result
         * to give us a negative number as a result. */
        if (left_neg ^ right_neg)
           result = -result;
         
        return result;
     }

  /*--------------------------------------------------------------*\
  |                          FixedDivide                           |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  This function returns the result of dividing two fixed-point  |
  |  numbers. Input fLeft is the left-side of the implied division |
  |  sign. It is the first value to divide. Input fRight is the    |
  |  right-side of the implied division sign. It is the value to   |
  |  divide the first value by. The fixed-point numbers are        |
  |  assumed to be in 16:16 form, although the routine might work  |
  |  for any other fixed-point setup, as long as the two values    |
  |  are identical in their fixed-point setup. But this has not    |
  |  been tested. Division of fixed-point numbers is defined as    |
  |  dividing the mantissas, and subtracting the exponents. Since  |
  |  we are implying 16:16 numbers, the subtraction of exponents   |
  |  would leave us with no fractional part. To solve this         |
  |  problem, we try to shift the numerator up by 16 bits.         |
  |  However, many compilers do not support 64-bit numbers, so we  |
  |  have to improvise a way to do the division without resorting  |
  |  to assembly language or unsupported types.                    |
  |                                                                |
  \*--------------------------------------------------------------*/

     an_Fixed an_FixedDivide(an_Fixed fLeft, an_Fixed fRight)
     {
        unsigned int left_neg = (fLeft & 0x80000000) != 0;
        unsigned int right_neg = (fRight & 0x80000000) != 0;
         
        /* Make sure we're using positive numbers for the division. We'll handle sign later. */
        unsigned long lefttemp = (left_neg ? -fLeft : fLeft);
        unsigned long righttemp = (right_neg ? -fRight : fRight);
         
        an_Fixed result = 0;
        unsigned char shiftbits = 16;
        
        /* We'll check the simple cases. */
        /* First, no integer component in the numerator (i.e. left < 1).
         * If this is the case, then we chop off the upper word (turn the number into a 0:32
         * number), and perform the division. */
        if ((lefttemp >> 16) == 0)	
           result = (lefttemp << 16) / righttemp;
        else
           /* Second, no fractional portion in the denominator (i.e. it's a whole number).
            * If this is the case, then we chop off the lower word (turn the number into a 32:0
            * number), and perform the division. */
           if ((righttemp << 16) == 0)
              result = lefttemp / (righttemp >> 16);
           else
           {
              /* Check to see if the numerator is less than the denominator.
               * If so, we'll shift up the numerator as far as we can of the 16 bits
               * we want to shift by, do the divison, then shift the result by the remaining
               * bits of the 16 bits. */
              if (lefttemp < righttemp)
              {
                 while ((shiftbits) && ((lefttemp & 0x80000000) == 0))
                 {
                    lefttemp <<= 1;
                    shiftbits--;
                 }
                 result = (lefttemp / righttemp) << shiftbits;
              }
              else
              {
                 /* Finally, if all else fails, we will do this the long way. Like elementary math,
                  * we will do this by repeatedly dividing, and using the remainder as part of the
                  * next division, until we have no remainder, or we run out of the 16-bits we need
                  * to do the 16:32 effect. */
                 while (((lefttemp & 0x80000000) == 0) &&
                        ((righttemp & 0x80000000) == 0) &&
                        ((righttemp & 0x0000FFFF) != 0))
                 {
                    lefttemp <<= 1;
                    righttemp <<= 1;
                 }
                 result = lefttemp / righttemp;
                 lefttemp = lefttemp % righttemp;
         
                 while ((lefttemp > 0) &&
                        (shiftbits > 0 ))
                 {
                    while (((lefttemp & 0x80000000) == 0) &&
                       (shiftbits != 0))
                    {
                       lefttemp <<= 1;
                       result <<= 1;
                       shiftbits--;
                    }
        
                    result += lefttemp / righttemp;
                    lefttemp = lefttemp % righttemp;
                 }
              }
           }
        
        /* Lastly, we check to see whether one, but not both, of the operators was negative.
         * If so, negate the result. */
        if (left_neg ^ right_neg)
           result = -result;
        
        return result;
     }

/********************************************************************\
 *                           Internal API                           * 
\********************************************************************/

  /*--------------------------------------------------------------*\
  |                     BuildReconfigDataBlock                     |
  +----------------------------------------------------------------+
  |                                                                |
  |  Description                                                   |
  |  ------------------------------                                |
  |  Called by other API functions and should not be directly      |
  |  called by the user. The heart of the reconfiguration API,     |
  |  this function packages an address and a list of values into   |
  |  the proper reconfiguration format, adhering to current        |
  |  auto-grow and CRC16 policies.                                 |
  |                                                                |
  \*--------------------------------------------------------------*/

     void an_BuildReconfigDataBlock(an_Chip chip, an_Byte bank, an_Byte byteNum, an_Byte* values, short count)
     {
        an_apiReconfigInfo* pInfo = an_apiReconfigData[chip];
        short updateIndex = 0;
        
        /* The size we expect this update to be.  This may change, depending on 
           update mode and CRC setting */
        short updateSize = 4 + count;
        
        /* If there was a previous update, we need to set its
           update to follow bit*/
        if (pInfo->lastUpdateIndex)
        {
           /* Set the update to follow bit */
           pInfo->data[pInfo->lastUpdateIndex] = pInfo->data[pInfo->lastUpdateIndex] | 0x40;
        }
        
        /* The address.  High bit must always be set. */
        pInfo->data[pInfo->length]     = byteNum | 0x80;
        pInfo->data[pInfo->length + 1] = bank;
        
        /* Number of bytes to write */
        pInfo->data[pInfo->length + 2] = (count == 256) ? 0 : count;
        
        /* The data */
        for (updateIndex = 0; updateIndex < count; updateIndex++)
        {
           pInfo->data[pInfo->length + (3 + updateIndex)] = values[updateIndex];
        }
        
        /* Error checking byte */
        pInfo->data[pInfo->length + (3 + count)] = ~an_apiSynchByte;
        
        /* Need to store where the address of this update is so we know for the next one */
        pInfo->lastUpdateIndex = pInfo->length;
        
        /* Update how much stuff is in this stream */
        pInfo->length = pInfo->length + updateSize;
     }

