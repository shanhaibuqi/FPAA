#pragma once

class systemB_IC_Integrator1
{
public:
   systemB_IC_Integrator1();

   //-----------------------------------------------------------
   //  A full floating-point method for setting the Integration      
   //  constant (in 1/microseconds) of this module.                  
   //-----------------------------------------------------------
   double setIntegrator(double K);

private:
   an_CAM m_instance;
};
