#pragma once

class systemA_SumDiff3
{
public:
   systemA_SumDiff3();

   //-----------------------------------------------------------
   //  A fixed-point method for setting the gain of the inputs of    
   //  this module.                                                  
   //-----------------------------------------------------------
   void fixedp_setGainSumDiff_3in(double G1, double G2, double G3);

   //-----------------------------------------------------------
   //  A full floating-point method for setting the gain of the      
   //  inputs of this module.                                        
   //-----------------------------------------------------------
   void setGainSumDiff_3in(double G1, double G2, double G3);

private:
   an_CAM m_instance;
};
