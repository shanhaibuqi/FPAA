#include "stdafx.h"
#include "systemB_IC_SumDiff2.h"

systemB_IC_SumDiff2::systemB_IC_SumDiff2()
{
   m_instance = an_systemB_IC_SumDiff2;
}

//-----------------------------------------------------------
//  A fixed-point method for setting the gain of the inputs of    
//  this module.                                                  
//-----------------------------------------------------------
void systemB_IC_SumDiff2::fixedp_setGainSumDiff_2in(double G1, double G2)
{
   an_fixedp_setGainSumDiff_2in(m_instance, G1, G2);
}

//-----------------------------------------------------------
//  A full floating-point method for setting the gain of the      
//  inputs of this module.                                        
//-----------------------------------------------------------
void systemB_IC_SumDiff2::setGainSumDiff_2in(double G1, double G2)
{
   an_setGainSumDiff_2in(m_instance, G1, G2);
}

