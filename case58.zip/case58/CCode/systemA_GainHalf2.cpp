#include "stdafx.h"
#include "systemA_GainHalf2.h"

systemA_GainHalf2::systemA_GainHalf2()
{
   m_instance = an_systemA_GainHalf2;
}

//-----------------------------------------------------------
//  A full fixed-point method for setting the gain of the module.  
//  It accepts floating-point inputs and returns a floating-point  
//  result.                                                       
//-----------------------------------------------------------
double systemA_GainHalf2::fixed_setGainHalf(double G)
{
   return an_fixed_setGainHalf(m_instance, G);
}

//-----------------------------------------------------------
//  A full floating point method for setting the gain of this     
//  module.                                                       
//-----------------------------------------------------------
double systemA_GainHalf2::setGainHalf(double G)
{
   return an_setGainHalf(m_instance, G);
}

