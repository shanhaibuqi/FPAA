#include "stdafx.h"
#include "systemB_Integrator4.h"

systemB_Integrator4::systemB_Integrator4()
{
   m_instance = an_systemB_Integrator4;
}

//-----------------------------------------------------------
//  A full floating-point method for setting the Integration      
//  constant (in 1/microseconds) of this module.                  
//-----------------------------------------------------------
double systemB_Integrator4::setIntegrator(double K)
{
   return an_setIntegrator(m_instance, K);
}

