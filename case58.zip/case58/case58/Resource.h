//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by case58.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CASE58_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_PORT                        1000
#define IDC_ABOUT                       1001
#define IDC_DOWNLOAD                    1002
#define IDC_RESET                       1003
#define IDC_SAMPLE_SLIDER               1004
#define IDC_SAMPLE_EDIT                 1005





// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1100
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
